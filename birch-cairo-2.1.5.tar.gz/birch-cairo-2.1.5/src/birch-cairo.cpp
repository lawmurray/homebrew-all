namespace birch {
#line 3 "src/Context.birch"
Context_::Context_() :
    #line 3 "src/Context.birch"
    base_type_() {
  //
}

#line 16 "src/Context.birch"
void Context_::destroy() {
  #line 17 "src/Context.birch"

    cairo_destroy(this->cr);
    }

#line 25 "src/Context.birch"
void Context_::newPath() {
  #line 26 "src/Context.birch"

    cairo_new_path(this->cr);
    }

#line 34 "src/Context.birch"
void Context_::closePath() {
  #line 35 "src/Context.birch"

    cairo_close_path(this->cr);
    }

#line 43 "src/Context.birch"
void Context_::arc(const Real& xc, const Real& yc, const Real& radius, const Real& angle1, const Real& angle2) {
  #line 44 "src/Context.birch"

    cairo_arc(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 52 "src/Context.birch"
void Context_::arcNegative(const Real& xc, const Real& yc, const Real& radius, const Real& angle1, const Real& angle2) {
  #line 53 "src/Context.birch"

    cairo_arc_negative(this->cr, xc, yc, radius, angle1, angle2);
    }

#line 61 "src/Context.birch"
void Context_::curveTo(const Real& x1, const Real& y1, const Real& x2, const Real& y2, const Real& x3, const Real& y3) {
  #line 62 "src/Context.birch"

    cairo_curve_to(this->cr, x1, y1, x2, y2, x3, y3);
    }

#line 70 "src/Context.birch"
void Context_::lineTo(const Real& x, const Real& y) {
  #line 71 "src/Context.birch"

    cairo_line_to(this->cr, x, y);
    }

#line 79 "src/Context.birch"
void Context_::moveTo(const Real& x, const Real& y) {
  #line 80 "src/Context.birch"

    cairo_move_to(this->cr, x, y);
    }

#line 88 "src/Context.birch"
void Context_::rectangle(const Real& x, const Real& y, const Real& width, const Real& height) {
  #line 89 "src/Context.birch"

    cairo_rectangle(this->cr, x, y, width, height);
    }

#line 97 "src/Context.birch"
void Context_::relCurveTo(const Real& dx1, const Real& dy1, const Real& dx2, const Real& dy2, const Real& dx3, const Real& dy3) {
  #line 98 "src/Context.birch"

    cairo_curve_to(this->cr, dx1, dy1, dx2, dy2, dx3, dy3);
    }

#line 106 "src/Context.birch"
void Context_::relLineTo(const Real& dx, const Real& dy) {
  #line 107 "src/Context.birch"

    cairo_line_to(this->cr, dx, dy);
    }

#line 115 "src/Context.birch"
void Context_::relMoveTo(const Real& dx, const Real& dy) {
  #line 116 "src/Context.birch"

    cairo_move_to(this->cr, dx, dy);
    }

#line 124 "src/Context.birch"
void Context_::stroke() {
  #line 125 "src/Context.birch"

    cairo_stroke(this->cr);
    }

#line 133 "src/Context.birch"
void Context_::strokePreserve() {
  #line 134 "src/Context.birch"

    cairo_stroke_preserve(this->cr);
    }

#line 142 "src/Context.birch"
void Context_::fill() {
  #line 143 "src/Context.birch"

    cairo_fill(this->cr);
    }

#line 151 "src/Context.birch"
void Context_::fillPreserve() {
  #line 152 "src/Context.birch"

    cairo_fill_preserve(this->cr);
    }

#line 160 "src/Context.birch"
void Context_::paint() {
  #line 161 "src/Context.birch"

    cairo_paint(this->cr);
    }

#line 169 "src/Context.birch"
void Context_::translate(const Real& tx, const Real& ty) {
  #line 170 "src/Context.birch"

    cairo_translate(this->cr, tx, ty);
    }

#line 178 "src/Context.birch"
void Context_::scale(const Real& sx, const Real& sy) {
  #line 179 "src/Context.birch"

    cairo_scale(this->cr, sx, sy);
    }

#line 187 "src/Context.birch"
void Context_::rotate(const Real& angle) {
  #line 188 "src/Context.birch"

    cairo_rotate(this->cr, angle);
    }

#line 196 "src/Context.birch"
std::tuple<Real, Real> Context_::deviceToUserDistance(const Real& ux, const Real& uy) {
  #line 197 "src/Context.birch"

    double ux1, uy1;
    cairo_device_to_user_distance(this->cr, &ux1, &uy1);
      #line 201 "src/Context.birch"
  return std::make_tuple(ux1, uy1);
}

#line 207 "src/Context.birch"
void Context_::setSourceRGB(const Real& red, const Real& green, const Real& blue) {
  #line 208 "src/Context.birch"

    cairo_set_source_rgb(this->cr, red, green, blue);
    }

#line 216 "src/Context.birch"
void Context_::setSourceRGBA(const Real& red, const Real& green, const Real& blue, const Real& alpha) {
  #line 217 "src/Context.birch"

    cairo_set_source_rgba(this->cr, red, green, blue, alpha);
    }

#line 225 "src/Context.birch"
void Context_::setSource(const Pattern& pattern) {
  #line 226 "src/Context.birch"

    cairo_set_source(this->cr, pattern->pattern);
    }

#line 234 "src/Context.birch"
void Context_::setLineWidth(const Real& width) {
  #line 235 "src/Context.birch"

    cairo_set_line_width(this->cr, width);
    }

#line 243 "src/Context.birch"
void Context_::showText(const String& utf8) {
  #line 244 "src/Context.birch"

    cairo_show_text(this->cr, utf8.c_str());
    }

#line 252 "src/Context.birch"
void Context_::setFontSize(const Real& size) {
  #line 253 "src/Context.birch"

    cairo_set_font_size(this->cr, size);
    }

#line 261 "src/Context.birch"
void Context_::pushGroup() {
  #line 262 "src/Context.birch"

    cairo_push_group(this->cr);
    }

#line 270 "src/Context.birch"
void Context_::popGroupToSource() {
  #line 271 "src/Context.birch"

    cairo_pop_group_to_source(this->cr);
    }

#line 3 "src/Context.birch"
Object_* make_Context_() {
  #line 3 "src/Context.birch"
  return new Context_();
  #line 3 "src/Context.birch"
}
static int register_factory_Context_ = ::register_factory("Context", make_Context_);


/**
 *
 */
#line 280 "src/Context.birch"
Context create(const Surface& surface) {
  Context cr;
  #line 282 "src/Context.birch"

  cr->cr = cairo_create(surface->surface);
    #line 285 "src/Context.birch"
  return cr;
}

}
namespace birch {
#line 1 "src/Pattern.birch"
Pattern_::Pattern_() :
    #line 1 "src/Pattern.birch"
    base_type_() {
  //
}

#line 12 "src/Pattern.birch"
void Pattern_::addColorStopRGB(const Real& offset, const Real& red, const Real& green, const Real& blue) {
  #line 13 "src/Pattern.birch"

    cairo_pattern_add_color_stop_rgb(this->pattern, offset, red, green, blue);
    }

#line 21 "src/Pattern.birch"
void Pattern_::addColorStopRGBA(const Real& offset, const Real& red, const Real& green, const Real& blue, const Real& alpha) {
  #line 23 "src/Pattern.birch"

    cairo_pattern_add_color_stop_rgba(this->pattern, offset, red, green, blue,
        alpha);
    }

#line 32 "src/Pattern.birch"
void Pattern_::destroy() {
  #line 33 "src/Pattern.birch"

    cairo_pattern_destroy(this->pattern);
    }

#line 1 "src/Pattern.birch"
Object_* make_Pattern_() {
  #line 1 "src/Pattern.birch"
  return new Pattern_();
  #line 1 "src/Pattern.birch"
}
static int register_factory_Pattern_ = ::register_factory("Pattern", make_Pattern_);


/**
 *
 */
#line 42 "src/Pattern.birch"
Pattern createRGB(const Real& red, const Real& green, const Real& blue) {
  Pattern result;
  #line 44 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_rgb(red, green, blue);
    #line 47 "src/Pattern.birch"
  return result;
}


/**
 *
 */
#line 53 "src/Pattern.birch"
Pattern createRGBA(const Real& red, const Real& green, const Real& blue, const Real& alpha) {
  Pattern result;
  #line 55 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_rgba(red, green, blue, alpha);
    #line 58 "src/Pattern.birch"
  return result;
}


/**
 *
 */
#line 64 "src/Pattern.birch"
Pattern createLinear(const Real& x0, const Real& y0, const Real& x1, const Real& y1) {
  Pattern result;
  #line 66 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_linear(x0, y0, x1, y1);
    #line 69 "src/Pattern.birch"
  return result;
}


/**
 *
 */
#line 75 "src/Pattern.birch"
Pattern createRadial(const Real& cx0, const Real& cy0, const Real& radius0, const Real& cx1, const Real& cy1, const Real& radius1) {
  Pattern result;
  #line 78 "src/Pattern.birch"

  result->pattern = cairo_pattern_create_radial(cx0, cy0, radius0, cx1,
      cy1, radius1);
    #line 82 "src/Pattern.birch"
  return result;
}

}
namespace birch {
#line 1 "src/Surface.birch"
Surface_::Surface_() :
    #line 1 "src/Surface.birch"
    base_type_() {
  //
}

#line 12 "src/Surface.birch"
void Surface_::destroy() {
  #line 13 "src/Surface.birch"

    cairo_surface_destroy(this->surface);
    }

#line 1 "src/Surface.birch"
Object_* make_Surface_() {
  #line 1 "src/Surface.birch"
  return new Surface_();
  #line 1 "src/Surface.birch"
}
static int register_factory_Surface_ = ::register_factory("Surface", make_Surface_);

}
namespace birch {
#line 3 "src/SurfacePDF.birch"
SurfacePDF_::SurfacePDF_() :
    #line 3 "src/SurfacePDF.birch"
    base_type_() {
  //
}

#line 3 "src/SurfacePDF.birch"
Object_* make_SurfacePDF_() {
  #line 3 "src/SurfacePDF.birch"
  return new SurfacePDF_();
  #line 3 "src/SurfacePDF.birch"
}
static int register_factory_SurfacePDF_ = ::register_factory("SurfacePDF", make_SurfacePDF_);


/**
 *
 */
#line 15 "src/SurfacePDF.birch"
Surface createPDF(const String& filename, const Real& widthInPoints, const Real& heightInPoints) {
  #line 17 "src/SurfacePDF.birch"
  mkdir(filename);
  SurfacePDF surface;
  #line 19 "src/SurfacePDF.birch"

  surface->surface = cairo_pdf_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 23 "src/SurfacePDF.birch"
  return surface;
}

}
namespace birch {
#line 1 "src/SurfacePNG.birch"
SurfacePNG_::SurfacePNG_() :
    #line 1 "src/SurfacePNG.birch"
    base_type_(),
    #line 5 "src/SurfacePNG.birch"
    filename() {
  //
}

#line 10 "src/SurfacePNG.birch"
void SurfacePNG_::destroy() {
  #line 12 "src/SurfacePNG.birch"
  mkdir(filename);
  #line 13 "src/SurfacePNG.birch"

    cairo_surface_write_to_png(this->surface, this->filename.c_str());
      #line 16 "src/SurfacePNG.birch"
  this->base_type_::destroy();
}

#line 1 "src/SurfacePNG.birch"
Object_* make_SurfacePNG_() {
  #line 1 "src/SurfacePNG.birch"
  return new SurfacePNG_();
  #line 1 "src/SurfacePNG.birch"
}
static int register_factory_SurfacePNG_ = ::register_factory("SurfacePNG", make_SurfacePNG_);


/**
 *
 */
#line 23 "src/SurfacePNG.birch"
Surface createPNG(const String& filename, const Integer& width, const Integer& height) {
  SurfacePNG surface;
  #line 26 "src/SurfacePNG.birch"

  surface->filename = filename;
  surface->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32,
      width, height);
    #line 31 "src/SurfacePNG.birch"
  return surface;
}

}
namespace birch {
#line 3 "src/SurfaceSVG.birch"
SurfaceSVG_::SurfaceSVG_() :
    #line 3 "src/SurfaceSVG.birch"
    base_type_() {
  //
}

#line 3 "src/SurfaceSVG.birch"
Object_* make_SurfaceSVG_() {
  #line 3 "src/SurfaceSVG.birch"
  return new SurfaceSVG_();
  #line 3 "src/SurfaceSVG.birch"
}
static int register_factory_SurfaceSVG_ = ::register_factory("SurfaceSVG", make_SurfaceSVG_);


/**
 *
 */
#line 15 "src/SurfaceSVG.birch"
Surface createSVG(const String& filename, const Real& widthInPoints, const Real& heightInPoints) {
  #line 17 "src/SurfaceSVG.birch"
  mkdir(filename);
  SurfaceSVG surface;
  #line 19 "src/SurfaceSVG.birch"

  surface->surface = cairo_svg_surface_create(filename.c_str(),
      widthInPoints, heightInPoints);
    #line 23 "src/SurfaceSVG.birch"
  return surface;
}

}
