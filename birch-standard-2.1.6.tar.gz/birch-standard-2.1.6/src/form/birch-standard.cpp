namespace birch {
}
namespace birch {
#line 7 "src/form/Form.birch"
Form::Form() {
  //
}

}
namespace birch {
}
namespace birch {
}
