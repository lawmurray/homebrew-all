namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {

/**
 * Filter a model.
 *
 *     birch filter [options...]
 *
 * - `--config`: Name of the configuration file, if any.
 *
 * - `--seed`: Random number seed. If used, overrides `seed` in the config
 *   file, which in turns overrides random entropy.
 *
 * - `--model`: Name of the model class. If used, overrides `model.class` in
 *   the config file.
 *
 * - `--filter`: Name of the filter class. If used, overrides
 *   `filter.class` in the config file, which in turn overrides the default
 *   of [ParticleFilter](../ParticleFilter).
 *
 * - `--kernel`: Name of the kernel class. If used, overrides
 *   `kernel.class` in the config file, which in turn overrides the default
 *   of [LangevinKernel](../LangevinKernel).
 *
 * - `--nsteps`: Number of steps to take. If used, this overrides `nsteps` in
 *   the config file, which in turn overrides `filter.nsteps` (deprecated) in
 *   the config file, which in turn overrides the number of steps derived from
 *   the input file, which in turn overrides the default of 0.
 *
 * - `--nforecasts`: Number of forecasts at each step. If used, this overrides
 *   `nforecasts` in the config file, which in turn overrides
 *   `filter.nforecasts` (deprecated) in the config file, which in turn
 *   overrides the number of forecasts derived from the input file, which in
 *   turn overrides the default of 0.
 *
 * - `--input`: Name of the input file, if any. If used, overrides `input` in
 *   the config file.
 *
 * - `--output`: Name of the output file, if any. If used, overrides `output`
 *   in the config file.
 *
 * - `--quiet true`: Don't display a progress bar.
 */
#line 41 "src/filter.birch"
int filter(int argc_, char** argv_) {
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> config;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<Integer> seed;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> model;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> filter;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> kernel;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<Integer> nsteps;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<Integer> nforecasts;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> input;
  #line 41 "src/filter.birch"
  [[maybe_unused]] std::optional<String> output;
  #line 41 "src/filter.birch"
  [[maybe_unused]] Boolean quiet = false;
  
  enum {
    configFLAG_,
    seedFLAG_,
    modelFLAG_,
    filterFLAG_,
    kernelFLAG_,
    nstepsFLAG_,
    nforecastsFLAG_,
    inputFLAG_,
    outputFLAG_,
    quietFLAG_,
  };
  #line 41 "src/filter.birch"
  int c_, option_index_;
  #line 41 "src/filter.birch"
  option long_options_[] = {
    #line 41 "src/filter.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 41 "src/filter.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 41 "src/filter.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 41 "src/filter.birch"
    {"filter", required_argument, 0, filterFLAG_ },
    #line 41 "src/filter.birch"
    {"kernel", required_argument, 0, kernelFLAG_ },
    #line 41 "src/filter.birch"
    {"nsteps", required_argument, 0, nstepsFLAG_ },
    #line 41 "src/filter.birch"
    {"nforecasts", required_argument, 0, nforecastsFLAG_ },
    #line 41 "src/filter.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 41 "src/filter.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 41 "src/filter.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 41 "src/filter.birch"
    {0, 0, 0, 0}
  #line 41 "src/filter.birch"
  };
  #line 41 "src/filter.birch"
  const char* short_options_ = ":";
  #line 41 "src/filter.birch"
  ::opterr = 0;
  #line 41 "src/filter.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 41 "src/filter.birch"
  while (c_ != -1) {
    #line 41 "src/filter.birch"
    switch (c_) {
      #line 42 "src/filter.birch"
      case configFLAG_:
        #line 42 "src/filter.birch"
        if (!::optarg) {
          #line 42 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 42 "src/filter.birch"
        }
        #line 42 "src/filter.birch"
        config = String(::optarg);
        #line 42 "src/filter.birch"
        break;
      #line 43 "src/filter.birch"
      case seedFLAG_:
        #line 43 "src/filter.birch"
        if (!::optarg) {
          #line 43 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 43 "src/filter.birch"
        }
        #line 43 "src/filter.birch"
        seed = from_string<Integer>(String(::optarg));
        #line 43 "src/filter.birch"
        break;
      #line 44 "src/filter.birch"
      case modelFLAG_:
        #line 44 "src/filter.birch"
        if (!::optarg) {
          #line 44 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 44 "src/filter.birch"
        }
        #line 44 "src/filter.birch"
        model = String(::optarg);
        #line 44 "src/filter.birch"
        break;
      #line 45 "src/filter.birch"
      case filterFLAG_:
        #line 45 "src/filter.birch"
        if (!::optarg) {
          #line 45 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 45 "src/filter.birch"
        }
        #line 45 "src/filter.birch"
        filter = String(::optarg);
        #line 45 "src/filter.birch"
        break;
      #line 46 "src/filter.birch"
      case kernelFLAG_:
        #line 46 "src/filter.birch"
        if (!::optarg) {
          #line 46 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 46 "src/filter.birch"
        }
        #line 46 "src/filter.birch"
        kernel = String(::optarg);
        #line 46 "src/filter.birch"
        break;
      #line 47 "src/filter.birch"
      case nstepsFLAG_:
        #line 47 "src/filter.birch"
        if (!::optarg) {
          #line 47 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 47 "src/filter.birch"
        }
        #line 47 "src/filter.birch"
        nsteps = from_string<Integer>(String(::optarg));
        #line 47 "src/filter.birch"
        break;
      #line 48 "src/filter.birch"
      case nforecastsFLAG_:
        #line 48 "src/filter.birch"
        if (!::optarg) {
          #line 48 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 48 "src/filter.birch"
        }
        #line 48 "src/filter.birch"
        nforecasts = from_string<Integer>(String(::optarg));
        #line 48 "src/filter.birch"
        break;
      #line 49 "src/filter.birch"
      case inputFLAG_:
        #line 49 "src/filter.birch"
        if (!::optarg) {
          #line 49 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 49 "src/filter.birch"
        }
        #line 49 "src/filter.birch"
        input = String(::optarg);
        #line 49 "src/filter.birch"
        break;
      #line 50 "src/filter.birch"
      case outputFLAG_:
        #line 50 "src/filter.birch"
        if (!::optarg) {
          #line 50 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 50 "src/filter.birch"
        }
        #line 50 "src/filter.birch"
        output = String(::optarg);
        #line 50 "src/filter.birch"
        break;
      #line 51 "src/filter.birch"
      case quietFLAG_:
        #line 51 "src/filter.birch"
        if (!::optarg) {
          #line 51 "src/filter.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 51 "src/filter.birch"
        }
        #line 51 "src/filter.birch"
        quiet = from_string<Boolean>(String(::optarg));
        #line 51 "src/filter.birch"
        break;
      #line 41 "src/filter.birch"
      case '?':
        #line 41 "src/filter.birch"
        error(String("unrecognized option ") + String(argv_[::optind - 1]));
      #line 41 "src/filter.birch"
      case ':':
        #line 41 "src/filter.birch"
        error(String("value required for option --") + String(long_options_[::optopt].name));
      #line 41 "src/filter.birch"
      default:
        #line 41 "src/filter.birch"
        error(String("unknown error parsing command-line options."));
    }
    #line 41 "src/filter.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  #line 41 "src/filter.birch"
  numbirch::init();

  #line 41 "src/filter.birch"
  birch::init();

  {
    Buffer configBuffer;
    #line 54 "src/filter.birch"
    if ((bool(config))) {
      #line 55 "src/filter.birch"
      configBuffer = slurp((*(config)));
    }
    #line 59 "src/filter.birch"
    if (!((bool(seed)))) {
      #line 60 "src/filter.birch"
      birch::optional_assign(seed, configBuffer->get<Integer>(String("seed")));
    }
    #line 62 "src/filter.birch"
    if ((bool(seed))) {
      #line 63 "src/filter.birch"
      birch::seed((*(seed)));
    } else {
      #line 65 "src/filter.birch"
      birch::seed();
    }
    Buffer modelBuffer;
    #line 70 "src/filter.birch"
    birch::optional_assign(modelBuffer, configBuffer->get(String("model")));
    #line 71 "src/filter.birch"
    if ((bool(model))) {
      #line 72 "src/filter.birch"
      modelBuffer->set(String("class"), (*(model)));
    }
    auto m = make<Model>(modelBuffer);
    #line 75 "src/filter.birch"
    if (!((bool(m)))) {
      #line 76 "src/filter.birch"
      error(String("could not create model; the model class should be given as ") + String("model.class in the config file, or `--model` on the command ") + String("line, and should derive from Model."));
    }
    Buffer filterBuffer;
    #line 83 "src/filter.birch"
    birch::optional_assign(filterBuffer, configBuffer->get(String("filter")));
    #line 84 "src/filter.birch"
    if ((bool(filter))) {
      #line 85 "src/filter.birch"
      filterBuffer->set(String("class"), (*(filter)));
    } else {
      #line 86 "src/filter.birch"
      if (!((bool(filterBuffer->get(String("class")))))) {
        #line 87 "src/filter.birch"
        filterBuffer->set(String("class"), String("ParticleFilter"));
      }
    }
    auto f = make<ParticleFilter>(filterBuffer);
    #line 90 "src/filter.birch"
    if (!((bool(f)))) {
      #line 91 "src/filter.birch"
      error(String("could not create filter; the filter class should be given as ") + String("filter.class in the config file, or --filter on the command ") + String("line, and should derive from ParticleFilter."));
    }
    Buffer kernelBuffer;
    #line 98 "src/filter.birch"
    birch::optional_assign(kernelBuffer, configBuffer->get(String("kernel")));
    #line 99 "src/filter.birch"
    if ((bool(kernel))) {
      #line 100 "src/filter.birch"
      kernelBuffer->set(String("class"), (*(kernel)));
    }
    auto \u03ba = make<Kernel>(kernelBuffer);
    #line 105 "src/filter.birch"
    if (!((bool(nsteps)))) {
      #line 106 "src/filter.birch"
      birch::optional_assign(nsteps, configBuffer->get<Integer>(String("nsteps")));
      #line 107 "src/filter.birch"
      if (!((bool(nsteps)))) {
        #line 108 "src/filter.birch"
        birch::optional_assign(nsteps, filterBuffer->get<Integer>(String("nsteps")));
        #line 109 "src/filter.birch"
        if ((bool(nsteps))) {
          #line 110 "src/filter.birch"
          warn(String("filter.nsteps in the config file is deprecated, replace ") + String("with nsteps in the config file, or --nsteps on the ") + String("command line."));
        }
      }
    }
    #line 118 "src/filter.birch"
    if (!((bool(nforecasts)))) {
      #line 119 "src/filter.birch"
      birch::optional_assign(nforecasts, configBuffer->get<Integer>(String("nforecasts")));
      #line 120 "src/filter.birch"
      if (!((bool(nforecasts)))) {
        #line 121 "src/filter.birch"
        birch::optional_assign(nforecasts, filterBuffer->get<Integer>(String("nforecasts")));
        #line 122 "src/filter.birch"
        if ((bool(nforecasts))) {
          #line 123 "src/filter.birch"
          warn(String("filter.nforecasts in the config file is deprecated, replace ") + String("with nforecasts in the config file, or --nforecasts on the ") + String("command line."));
        }
      }
    }
    auto inputPath = configBuffer->get<String>(String("input"));
    #line 132 "src/filter.birch"
    birch::optional_assign(inputPath, input);
    std::optional<Reader> inputReader;
    #line 134 "src/filter.birch"
    if ((bool(inputPath)) && (*(inputPath)) != String("")) {
      #line 135 "src/filter.birch"
      inputReader = make_reader((*(inputPath)));
    }
    auto outputPath = configBuffer->get<String>(String("output"));
    #line 140 "src/filter.birch"
    birch::optional_assign(outputPath, output);
    std::optional<Writer> outputWriter;
    #line 142 "src/filter.birch"
    if ((bool(outputPath)) && (*(outputPath)) != String("")) {
      #line 143 "src/filter.birch"
      outputWriter = make_writer((*(outputPath)));
    }
    ProgressBar bar;
    #line 148 "src/filter.birch"
    if (!(quiet)) {
      #line 149 "src/filter.birch"
      bar->update(Real(0.0));
    }
    auto t = 0;
    #line 154 "src/filter.birch"
    while (((bool(nsteps)) && t <= (*(nsteps))) || (!((bool(nsteps))) && (*(inputReader))->hasNext())) {
      auto inputBuffer = make_buffer();
      #line 157 "src/filter.birch"
      if ((bool(inputReader)) && (*(inputReader))->hasNext()) {
        #line 158 "src/filter.birch"
        inputBuffer = (*(inputReader))->next();
      }
      auto outputBuffer = make_buffer();
      auto filterInputBuffer = inputBuffer;
      #line 166 "src/filter.birch"
      birch::optional_assign(filterInputBuffer, inputBuffer->get(String("filter")));
      #line 167 "src/filter.birch"
      if (t == 0) {
        #line 168 "src/filter.birch"
        (*(f))->filter((*(m)), filterInputBuffer);
      } else {
        #line 169 "src/filter.birch"
        if ((bool(\u03ba))) {
          #line 170 "src/filter.birch"
          (*(f))->filter(t, filterInputBuffer, (*(\u03ba)));
        } else {
          #line 172 "src/filter.birch"
          (*(f))->filter(t, filterInputBuffer);
        }
      }
      auto filterOutputBuffer = make_buffer();
      #line 175 "src/filter.birch"
      filterOutputBuffer->set(String("sample"), t, (*(f))->x);
      #line 176 "src/filter.birch"
      filterOutputBuffer->set(String("lweight"), (*(f))->w);
      #line 177 "src/filter.birch"
      outputBuffer->set(String("step"), t);
      #line 178 "src/filter.birch"
      outputBuffer->set(String("ess"), (*(f))->ess);
      #line 179 "src/filter.birch"
      outputBuffer->set(String("lnormalize"), (*(f))->lnormalize);
      #line 180 "src/filter.birch"
      outputBuffer->set(String("npropagations"), (*(f))->npropagations);
      #line 181 "src/filter.birch"
      if ((bool((*(f))->raccepts))) {
        #line 182 "src/filter.birch"
        outputBuffer->set(String("raccepts"), (*((*(f))->raccepts)));
      } else {
        #line 184 "src/filter.birch"
        outputBuffer->setNil(String("raccepts"));
      }
      #line 186 "src/filter.birch"
      if ((bool(\u03ba))) {
        #line 187 "src/filter.birch"
        outputBuffer->set(String("scale"), (*(\u03ba))->scale);
      }
      #line 189 "src/filter.birch"
      outputBuffer->set(String("filter"), filterOutputBuffer);
      auto forecastSize = inputBuffer->size(String("forecast"));
      #line 193 "src/filter.birch"
      if ((bool(nforecasts))) {
        #line 194 "src/filter.birch"
        forecastSize = (*(nforecasts));
      }
      #line 196 "src/filter.birch"
      if (forecastSize > 0) {
        #line 201 "src/filter.birch"
        (*(f))->resample(t + 1, \u03ba);
        #line 204 "src/filter.birch"
        #if HAVE_NUMBIRCH_HPP
        numbirch::wait();
        #endif
        #pragma omp parallel
        {
          #pragma omp for schedule(guided)
          for (int n = int(1); n <= int((*(f))->x->size()); ++n) {
            #line 205 "src/filter.birch"
            bridge((*(f))->x(n));
          }
          #if HAVE_NUMBIRCH_HPP
          numbirch::wait();
          #endif
        }
        auto f_prime_ = copy((*(f)));
        #line 208 "src/filter.birch"
        f_prime_->reconfigure(false, false, false);
        auto forecastInputIterator = inputBuffer->walk(String("forecast"));
        #line 212 "src/filter.birch"
        for (int t_prime_ = int((t + 1)); t_prime_ <= int((t + forecastSize)); ++t_prime_) {
          auto forecastInputBuffer = inputBuffer;
          #line 214 "src/filter.birch"
          if (forecastInputIterator->hasNext()) {
            #line 215 "src/filter.birch"
            forecastInputBuffer = forecastInputIterator->next();
          }
          #line 217 "src/filter.birch"
          f_prime_->filter(t_prime_, forecastInputBuffer);
          auto forecastOutputBuffer = make_buffer();
          #line 219 "src/filter.birch"
          forecastOutputBuffer->set(String("sample"), t, f_prime_->x);
          #line 220 "src/filter.birch"
          forecastOutputBuffer->set(String("lweight"), f_prime_->w);
          #line 221 "src/filter.birch"
          outputBuffer->push(String("forecast"), forecastOutputBuffer);
        }
      }
      #line 225 "src/filter.birch"
      if ((bool(outputWriter))) {
        #line 226 "src/filter.birch"
        (*(outputWriter))->push(outputBuffer);
      }
      #line 228 "src/filter.birch"
      if (!(quiet) && (bool(nsteps))) {
        #line 229 "src/filter.birch"
        bar->update((t + Real(1.0)) / ((*(nsteps)) + Real(1.0)));
      }
      #line 231 "src/filter.birch"
      t = t + 1;
    }
    #line 235 "src/filter.birch"
    if ((bool(inputReader))) {
      #line 236 "src/filter.birch"
      (*(inputReader))->close();
    }
    #line 238 "src/filter.birch"
    if ((bool(outputWriter))) {
      #line 239 "src/filter.birch"
      (*(outputWriter))->close();
    }
  }
  #line 41 "src/filter.birch"
  birch::term();

  #line 41 "src/filter.birch"
  membirch::collect();
  #line 41 "src/filter.birch"
  numbirch::term();

  #line 41 "src/filter.birch"
  return 0;
}

static int register_program_filter_ = ::register_program("filter", filter);
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
#line 52 "src/registry.birch"

#include <map>

/**
 * Program function registry.
 */
static std::map<std::string,prog_t*>& programs() {
  static std::map<std::string,prog_t*> programs;
  return programs;
}
/**
 * Default-constructible object factory function registry.
 */
static std::map<std::string,fact_t*>& factories() {
  static std::map<std::string,fact_t*> factories;
  return factories;
}

extern "C" prog_t* retrieve_program(const std::string& name) {
  auto iter = programs().find(name);
  if (iter != programs().end()) {
    return iter->second;
  } else {
    return nullptr;
  }
}

int register_program(const std::string& name, prog_t* f) {
  programs()[name] = f;
  return 0;
}

extern "C" fact_t* retrieve_factory(const std::string& name) {
  auto iter = factories().find(name);
  if (iter != factories().end()) {
    return iter->second;
  } else {
    return nullptr;
  }
}

int register_factory(const std::string& name, fact_t* f) {
  factories()[name] = f;
  return 0;
}

namespace birch {
}
namespace birch {

/**
 * Sample a model.
 *
 *     birch sample [options...]
 *
 * - `--config`: Name of the configuration file, if any.
 *
 * - `--seed`: Random number seed. If used, overrides `seed` in the config
 *   file, which in turns overrides random entropy.
 *
 * - `--model`: Name of the model class. If used, overrides `model.class` in
 *   the config file.
 *
 * - `--sampler`: Name of the sampler class. If used, overrides
 *   `sampler.class` in the config file, which in turn overrides the default
 *   of [ParticleSampler](../ParticleSampler).
 *
 * - `--filter`: Name of the filter class. If used, overrides
 *   `filter.class` in the config file, which in turn overrides the default
 *   of [ParticleFilter](../ParticleFilter).
 *
 * - `--kernel`: Name of the kernel class. If used, overrides
 *   `kernel.class` in the config file, which in turn overrides the default
 *   of [LangevinKernel](../LangevinKernel).
 *
 * - `--nsamples`: Number of samples to draw. If used, this overrides
 *   `nsamples` in the config file, which in turn overrides `sampler.nsamples`
 *   (deprecated) in the config file, which in turn overrides the default of
 *   1.
 *
 * - `--nsteps`: Number of steps to take. If used, this overrides `nsteps` in
 *   the config file, which in turn overrides `filter.nsteps` (deprecated) in
 *   the config file, which in turn overrides the number of steps derived from
 *   the input file, which in turn overrides the default of 0.
 *
 * - `--input`: Name of the input file, if any. If used, overrides `input` in
 *   the config file.
 *
 * - `--output`: Name of the output file, if any. If used, overrides `output`
 *   in the config file.
 *
 * - `--quiet true`: Don't display a progress bar.
 */
#line 44 "src/sample.birch"
int sample(int argc_, char** argv_) {
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> config;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<Integer> seed;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> model;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> sampler;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> filter;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> kernel;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<Integer> nsamples;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<Integer> nsteps;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> input;
  #line 44 "src/sample.birch"
  [[maybe_unused]] std::optional<String> output;
  #line 44 "src/sample.birch"
  [[maybe_unused]] Boolean quiet = false;
  
  enum {
    configFLAG_,
    seedFLAG_,
    modelFLAG_,
    samplerFLAG_,
    filterFLAG_,
    kernelFLAG_,
    nsamplesFLAG_,
    nstepsFLAG_,
    inputFLAG_,
    outputFLAG_,
    quietFLAG_,
  };
  #line 44 "src/sample.birch"
  int c_, option_index_;
  #line 44 "src/sample.birch"
  option long_options_[] = {
    #line 44 "src/sample.birch"
    {"config", required_argument, 0, configFLAG_ },
    #line 44 "src/sample.birch"
    {"seed", required_argument, 0, seedFLAG_ },
    #line 44 "src/sample.birch"
    {"model", required_argument, 0, modelFLAG_ },
    #line 44 "src/sample.birch"
    {"sampler", required_argument, 0, samplerFLAG_ },
    #line 44 "src/sample.birch"
    {"filter", required_argument, 0, filterFLAG_ },
    #line 44 "src/sample.birch"
    {"kernel", required_argument, 0, kernelFLAG_ },
    #line 44 "src/sample.birch"
    {"nsamples", required_argument, 0, nsamplesFLAG_ },
    #line 44 "src/sample.birch"
    {"nsteps", required_argument, 0, nstepsFLAG_ },
    #line 44 "src/sample.birch"
    {"input", required_argument, 0, inputFLAG_ },
    #line 44 "src/sample.birch"
    {"output", required_argument, 0, outputFLAG_ },
    #line 44 "src/sample.birch"
    {"quiet", required_argument, 0, quietFLAG_ },
    #line 44 "src/sample.birch"
    {0, 0, 0, 0}
  #line 44 "src/sample.birch"
  };
  #line 44 "src/sample.birch"
  const char* short_options_ = ":";
  #line 44 "src/sample.birch"
  ::opterr = 0;
  #line 44 "src/sample.birch"
  c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  #line 44 "src/sample.birch"
  while (c_ != -1) {
    #line 44 "src/sample.birch"
    switch (c_) {
      #line 45 "src/sample.birch"
      case configFLAG_:
        #line 45 "src/sample.birch"
        if (!::optarg) {
          #line 45 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 45 "src/sample.birch"
        }
        #line 45 "src/sample.birch"
        config = String(::optarg);
        #line 45 "src/sample.birch"
        break;
      #line 46 "src/sample.birch"
      case seedFLAG_:
        #line 46 "src/sample.birch"
        if (!::optarg) {
          #line 46 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 46 "src/sample.birch"
        }
        #line 46 "src/sample.birch"
        seed = from_string<Integer>(String(::optarg));
        #line 46 "src/sample.birch"
        break;
      #line 47 "src/sample.birch"
      case modelFLAG_:
        #line 47 "src/sample.birch"
        if (!::optarg) {
          #line 47 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 47 "src/sample.birch"
        }
        #line 47 "src/sample.birch"
        model = String(::optarg);
        #line 47 "src/sample.birch"
        break;
      #line 48 "src/sample.birch"
      case samplerFLAG_:
        #line 48 "src/sample.birch"
        if (!::optarg) {
          #line 48 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 48 "src/sample.birch"
        }
        #line 48 "src/sample.birch"
        sampler = String(::optarg);
        #line 48 "src/sample.birch"
        break;
      #line 49 "src/sample.birch"
      case filterFLAG_:
        #line 49 "src/sample.birch"
        if (!::optarg) {
          #line 49 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 49 "src/sample.birch"
        }
        #line 49 "src/sample.birch"
        filter = String(::optarg);
        #line 49 "src/sample.birch"
        break;
      #line 50 "src/sample.birch"
      case kernelFLAG_:
        #line 50 "src/sample.birch"
        if (!::optarg) {
          #line 50 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 50 "src/sample.birch"
        }
        #line 50 "src/sample.birch"
        kernel = String(::optarg);
        #line 50 "src/sample.birch"
        break;
      #line 51 "src/sample.birch"
      case nsamplesFLAG_:
        #line 51 "src/sample.birch"
        if (!::optarg) {
          #line 51 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 51 "src/sample.birch"
        }
        #line 51 "src/sample.birch"
        nsamples = from_string<Integer>(String(::optarg));
        #line 51 "src/sample.birch"
        break;
      #line 52 "src/sample.birch"
      case nstepsFLAG_:
        #line 52 "src/sample.birch"
        if (!::optarg) {
          #line 52 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 52 "src/sample.birch"
        }
        #line 52 "src/sample.birch"
        nsteps = from_string<Integer>(String(::optarg));
        #line 52 "src/sample.birch"
        break;
      #line 53 "src/sample.birch"
      case inputFLAG_:
        #line 53 "src/sample.birch"
        if (!::optarg) {
          #line 53 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 53 "src/sample.birch"
        }
        #line 53 "src/sample.birch"
        input = String(::optarg);
        #line 53 "src/sample.birch"
        break;
      #line 54 "src/sample.birch"
      case outputFLAG_:
        #line 54 "src/sample.birch"
        if (!::optarg) {
          #line 54 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 54 "src/sample.birch"
        }
        #line 54 "src/sample.birch"
        output = String(::optarg);
        #line 54 "src/sample.birch"
        break;
      #line 55 "src/sample.birch"
      case quietFLAG_:
        #line 55 "src/sample.birch"
        if (!::optarg) {
          #line 55 "src/sample.birch"
          error(String("value required for option --") + String(long_options_[::optopt].name));
        #line 55 "src/sample.birch"
        }
        #line 55 "src/sample.birch"
        quiet = from_string<Boolean>(String(::optarg));
        #line 55 "src/sample.birch"
        break;
      #line 44 "src/sample.birch"
      case '?':
        #line 44 "src/sample.birch"
        error(String("unrecognized option ") + String(argv_[::optind - 1]));
      #line 44 "src/sample.birch"
      case ':':
        #line 44 "src/sample.birch"
        error(String("value required for option --") + String(long_options_[::optopt].name));
      #line 44 "src/sample.birch"
      default:
        #line 44 "src/sample.birch"
        error(String("unknown error parsing command-line options."));
    }
    #line 44 "src/sample.birch"
    c_ = ::getopt_long_only(argc_, argv_, short_options_, long_options_, &option_index_);
  }

  #line 44 "src/sample.birch"
  numbirch::init();

  #line 44 "src/sample.birch"
  birch::init();

  {
    Buffer configBuffer;
    #line 58 "src/sample.birch"
    if ((bool(config))) {
      #line 59 "src/sample.birch"
      configBuffer = slurp((*(config)));
    }
    #line 63 "src/sample.birch"
    if (!((bool(seed)))) {
      #line 64 "src/sample.birch"
      birch::optional_assign(seed, configBuffer->get<Integer>(String("seed")));
    }
    #line 66 "src/sample.birch"
    if ((bool(seed))) {
      #line 67 "src/sample.birch"
      birch::seed((*(seed)));
    } else {
      #line 69 "src/sample.birch"
      birch::seed();
    }
    Buffer modelBuffer;
    #line 74 "src/sample.birch"
    birch::optional_assign(modelBuffer, configBuffer->get(String("model")));
    #line 75 "src/sample.birch"
    if ((bool(model))) {
      #line 76 "src/sample.birch"
      modelBuffer->set(String("class"), (*(model)));
    }
    auto theModel = make<Model>(modelBuffer);
    #line 79 "src/sample.birch"
    if (!((bool(theModel)))) {
      #line 80 "src/sample.birch"
      error(String("could not create model; the model class should be given as ") + String("model.class in the config file, or `--model` on the command ") + String("line, and should derive from Model."));
    }
    Buffer samplerBuffer;
    #line 87 "src/sample.birch"
    birch::optional_assign(samplerBuffer, configBuffer->get(String("sampler")));
    #line 88 "src/sample.birch"
    if ((bool(sampler))) {
      #line 89 "src/sample.birch"
      samplerBuffer->set(String("class"), (*(sampler)));
    } else {
      #line 90 "src/sample.birch"
      if (!((bool(samplerBuffer->get(String("class")))))) {
        #line 91 "src/sample.birch"
        samplerBuffer->set(String("class"), String("ParticleSampler"));
      }
    }
    auto theSampler = make<ParticleSampler>(samplerBuffer);
    #line 94 "src/sample.birch"
    if (!((bool(theSampler)))) {
      #line 95 "src/sample.birch"
      error(String("could not create sampler; the sampler class should be given as ") + String("sampler.class in the config file, or --sampler on the command ") + String("line, and should derive from ParticleSampler."));
    }
    Buffer filterBuffer;
    #line 102 "src/sample.birch"
    birch::optional_assign(filterBuffer, configBuffer->get(String("filter")));
    #line 103 "src/sample.birch"
    if ((bool(filter))) {
      #line 104 "src/sample.birch"
      filterBuffer->set(String("class"), (*(filter)));
    } else {
      #line 105 "src/sample.birch"
      if (!((bool(filterBuffer->get(String("class")))))) {
        #line 106 "src/sample.birch"
        filterBuffer->set(String("class"), String("ParticleFilter"));
      }
    }
    auto theFilter = make<ParticleFilter>(filterBuffer);
    #line 109 "src/sample.birch"
    if (!((bool(theFilter)))) {
      #line 110 "src/sample.birch"
      error(String("could not create filter; the filter class should be given as ") + String("filter.class in the config file, or --filter on the command ") + String("line, and should derive from ParticleFilter."));
    }
    Buffer kernelBuffer;
    #line 117 "src/sample.birch"
    birch::optional_assign(kernelBuffer, configBuffer->get(String("kernel")));
    #line 118 "src/sample.birch"
    if ((bool(kernel))) {
      #line 119 "src/sample.birch"
      kernelBuffer->set(String("class"), (*(kernel)));
    }
    auto theKernel = make<Kernel>(kernelBuffer);
    #line 124 "src/sample.birch"
    if (!((bool(nsamples)))) {
      #line 125 "src/sample.birch"
      birch::optional_assign(nsamples, configBuffer->get<Integer>(String("nsamples")));
      #line 126 "src/sample.birch"
      if (!((bool(nsamples)))) {
        #line 127 "src/sample.birch"
        birch::optional_assign(nsamples, samplerBuffer->get<Integer>(String("nsamples")));
        #line 128 "src/sample.birch"
        if ((bool(nsamples))) {
        } else {
          #line 133 "src/sample.birch"
          nsamples = 1;
        }
      }
    }
    #line 139 "src/sample.birch"
    if (!((bool(nsteps)))) {
      #line 140 "src/sample.birch"
      birch::optional_assign(nsteps, configBuffer->get<Integer>(String("nsteps")));
      #line 141 "src/sample.birch"
      if (!((bool(nsteps)))) {
        #line 142 "src/sample.birch"
        birch::optional_assign(nsteps, filterBuffer->get<Integer>(String("nsteps")));
        #line 143 "src/sample.birch"
        if ((bool(nsteps))) {
        }
      }
    }
    auto inputPath = configBuffer->get<String>(String("input"));
    #line 153 "src/sample.birch"
    birch::optional_assign(inputPath, input);
    Buffer inputBuffer;
    #line 155 "src/sample.birch"
    inputBuffer->setEmptyArray();
    #line 156 "src/sample.birch"
    if ((bool(inputPath)) && (*(inputPath)) != String("")) {
      auto inputReader = make_reader((*(inputPath)));
      #line 158 "src/sample.birch"
      if (!((bool(nsteps)))) {
        #line 159 "src/sample.birch"
        inputBuffer = inputReader->slurp();
        #line 160 "src/sample.birch"
        nsteps = inputBuffer->size() - 1;
      } else {
        auto t = 0;
        #line 163 "src/sample.birch"
        while (t <= (*(nsteps)) && inputReader->hasNext()) {
          #line 164 "src/sample.birch"
          inputBuffer->push(inputReader->next());
          #line 165 "src/sample.birch"
          t = t + 1;
        }
      }
      #line 168 "src/sample.birch"
      inputReader->close();
    }
    #line 170 "src/sample.birch"
    if (!((bool(nsteps)))) {
      #line 171 "src/sample.birch"
      nsteps = 0;
    }
    auto outputPath = configBuffer->get<String>(String("output"));
    #line 176 "src/sample.birch"
    birch::optional_assign(outputPath, output);
    std::optional<Writer> outputWriter;
    #line 178 "src/sample.birch"
    if ((bool(outputPath)) && (*(outputPath)) != String("")) {
      #line 179 "src/sample.birch"
      outputWriter = make_writer((*(outputPath)));
    }
    ProgressBar bar;
    #line 184 "src/sample.birch"
    if (!(quiet)) {
      #line 185 "src/sample.birch"
      bar->update(Real(0.0));
    }
    Buffer buffer;
    #line 190 "src/sample.birch"
    for (int n = int(1); n <= int((*(nsamples))); ++n) {
      auto inputIter = inputBuffer->walk();
      #line 193 "src/sample.birch"
      if (inputIter->hasNext()) {
        #line 194 "src/sample.birch"
        buffer = inputIter->next();
      } else {
        #line 196 "src/sample.birch"
        buffer = make_buffer();
      }
      #line 198 "src/sample.birch"
      (*(theSampler))->sample((*(theFilter)), (*(theModel)), buffer);
      Buffer outputBuffer;
      #line 202 "src/sample.birch"
      if ((bool(outputWriter))) {
        #line 203 "src/sample.birch"
        outputBuffer->set(String("ess"), (*(theFilter))->ess);
        #line 204 "src/sample.birch"
        outputBuffer->set(String("lnormalize"), (*(theFilter))->lnormalize);
        #line 205 "src/sample.birch"
        outputBuffer->set(String("npropagations"), (*(theFilter))->npropagations);
        #line 206 "src/sample.birch"
        if ((bool((*(theFilter))->raccepts))) {
          #line 207 "src/sample.birch"
          outputBuffer->set(String("raccepts"), (*((*(theFilter))->raccepts)));
        } else {
          #line 209 "src/sample.birch"
          outputBuffer->setNil(String("raccepts"));
        }
      }
      #line 214 "src/sample.birch"
      if (!(quiet)) {
        #line 215 "src/sample.birch"
        bar->update((n - Real(1.0)) / (*(nsamples)) + Real(1.0) / ((*(nsamples)) * ((*(nsteps)) + Real(1.0))));
      }
      #line 219 "src/sample.birch"
      for (int t = int(1); t <= int((*(nsteps))); ++t) {
        #line 220 "src/sample.birch"
        if (inputIter->hasNext()) {
          #line 221 "src/sample.birch"
          buffer = inputIter->next();
        } else {
          #line 223 "src/sample.birch"
          buffer = make_buffer();
        }
        #line 225 "src/sample.birch"
        if ((bool(theKernel))) {
          #line 226 "src/sample.birch"
          (*(theSampler))->sample((*(theFilter)), t, buffer, (*(theKernel)));
        } else {
          #line 228 "src/sample.birch"
          (*(theSampler))->sample((*(theFilter)), t, buffer);
        }
        #line 232 "src/sample.birch"
        if ((bool(outputWriter))) {
          #line 233 "src/sample.birch"
          outputBuffer->push(String("ess"), (*(theFilter))->ess);
          #line 234 "src/sample.birch"
          outputBuffer->push(String("lnormalize"), (*(theFilter))->lnormalize);
          #line 235 "src/sample.birch"
          outputBuffer->push(String("npropagations"), (*(theFilter))->npropagations);
          #line 236 "src/sample.birch"
          if ((bool((*(theFilter))->raccepts))) {
            #line 237 "src/sample.birch"
            outputBuffer->push(String("raccepts"), (*((*(theFilter))->raccepts)));
          } else {
            #line 239 "src/sample.birch"
            outputBuffer->pushNil(String("raccepts"));
          }
        }
        #line 244 "src/sample.birch"
        if (!(quiet)) {
          #line 245 "src/sample.birch"
          bar->update((n - Real(1.0)) / (*(nsamples)) + (t + Real(1.0)) / ((*(nsamples)) * ((*(nsteps)) + Real(1.0))));
        }
      }
      #line 250 "src/sample.birch"
      if ((bool(outputWriter))) {
        auto n3231_ = (*(theSampler))->draw((*(theFilter)));
        auto x = std::move(std::get<0>(n3231_));
        auto w = std::move(std::get<1>(n3231_));
        #line 252 "src/sample.birch"
        outputBuffer->set(String("lweight"), w);
        #line 253 "src/sample.birch"
        outputBuffer->set(String("sample"), x);
        auto steps = make_buffer();
        auto atLeastOne = false;
        #line 260 "src/sample.birch"
        for (int t = int(1); t <= int((*(nsteps))); ++t) {
          auto step = make_buffer(t, x);
          #line 262 "src/sample.birch"
          atLeastOne = atLeastOne || !(step->isEmpty());
          #line 263 "src/sample.birch"
          steps->push(String("sample"), step);
        }
        #line 265 "src/sample.birch"
        if (atLeastOne) {
          auto iter = steps->walk();
          #line 267 "src/sample.birch"
          while (iter->hasNext()) {
            #line 268 "src/sample.birch"
            outputBuffer->push(String("sample"), iter->next());
          }
        }
        #line 271 "src/sample.birch"
        (*(outputWriter))->push(outputBuffer);
        #line 272 "src/sample.birch"
        (*(outputWriter))->flush();
      }
      #line 276 "src/sample.birch"
      if (!(quiet)) {
        #line 277 "src/sample.birch"
        bar->update(cast<Real>(n) / (*(nsamples)));
      }
    }
    #line 282 "src/sample.birch"
    if ((bool(outputWriter))) {
      #line 283 "src/sample.birch"
      (*(outputWriter))->close();
    }
  }
  #line 44 "src/sample.birch"
  birch::term();

  #line 44 "src/sample.birch"
  membirch::collect();
  #line 44 "src/sample.birch"
  numbirch::term();

  #line 44 "src/sample.birch"
  return 0;
}

static int register_program_sample_ = ::register_program("sample", sample);
}
namespace birch {

/**
 * Make an object, with the class given in a buffer.
 *
 *   @param buffer The buffer.
 *
 * @return An optional with a value if successful, or no value if not
 * successful.
 *
 * If the buffer contains a key `class`, an object of that class is 
 * constructed. The buffer is then passed to the `read()` function of the new
 * object.
 *
 * The make will not succeed if the class has initialization parameters.
 */
#line 266 "src/type.birch"
std::optional<Object> make(const Buffer& buffer) {
  std::optional<Object> result;
  auto className = buffer->get<String>(String("class"));
  #line 269 "src/type.birch"
  if ((bool(className))) {
    #line 270 "src/type.birch"
    result = make<Object>((*(className)));
  }
  #line 272 "src/type.birch"
  if ((bool(result))) {
    #line 273 "src/type.birch"
    (*(result))->read(buffer);
  }
  #line 275 "src/type.birch"
  return result;
}


/**
 * Make an object, with the class given in a buffer.
 *
 *   @param t Step number.
 *   @param buffer The buffer.
 *
 * @return An optional with a value if successful, or no value if not
 * successful.
 *
 * If the buffer contains a key `class`, an object of that class is 
 * constructed. The buffer is then passed to the `read()` function of the new
 * object.
 *
 * The make will not succeed if the class has initialization parameters.
 */
#line 293 "src/type.birch"
std::optional<Object> make(const Integer& t, const Buffer& buffer) {
  std::optional<Object> result;
  auto className = buffer->get<String>(String("class"));
  #line 296 "src/type.birch"
  if ((bool(className))) {
    #line 297 "src/type.birch"
    result = make<Object>((*(className)));
  }
  #line 299 "src/type.birch"
  if ((bool(result))) {
    #line 300 "src/type.birch"
    (*(result))->read(t, buffer);
  }
  #line 302 "src/type.birch"
  return result;
}

}
namespace birch {
}
