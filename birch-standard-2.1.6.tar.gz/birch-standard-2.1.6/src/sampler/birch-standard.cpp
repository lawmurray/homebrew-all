namespace birch {
#line 1 "src/sampler/AliveParticleFilter.birch"
AliveParticleFilter_::AliveParticleFilter_() :
    #line 1 "src/sampler/AliveParticleFilter.birch"
    base_type_() {
  //
}

#line 15 "src/sampler/AliveParticleFilter.birch"
void AliveParticleFilter_::simulate(const Integer& t, const Buffer& input) {
  #line 18 "src/sampler/AliveParticleFilter.birch"
  #if HAVE_NUMBIRCH_HPP
  numbirch::wait();
  #endif
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (int n = int(1); n <= int(nparticles); ++n) {
      #line 19 "src/sampler/AliveParticleFilter.birch"
      bridge(x(n));
    }
    #if HAVE_NUMBIRCH_HPP
    numbirch::wait();
    #endif
  }
  auto x0 = copy(x);
  auto w0 = w;
  auto p = vector(0, nparticles);
  auto n3236_ = resample_systematic(w);
  auto a = std::move(std::get<0>(n3236_));
  auto o = std::move(std::get<1>(n3236_));
  #line 28 "src/sampler/AliveParticleFilter.birch"
  #if HAVE_NUMBIRCH_HPP
  numbirch::wait();
  #endif
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (int n = int(1); n <= int(nparticles); ++n) {
      #line 29 "src/sampler/AliveParticleFilter.birch"
      do {
        #line 30 "src/sampler/AliveParticleFilter.birch"
        x(n) = birch::copy(x0(a(n)));
        #line 31 "src/sampler/AliveParticleFilter.birch"
        p(n) = p(n) + 1;
        auto m = x(n);
        auto h = construct<Handler>(autoconj, autodiff, autojoin);
        #line 35 "src/sampler/AliveParticleFilter.birch"
        {
          auto handler_ = swap_handler(h);
          #line 36 "src/sampler/AliveParticleFilter.birch"
          x(n)->read(t, input);
          #line 37 "src/sampler/AliveParticleFilter.birch"
          x(n)->simulate(t);
          set_handler(handler_);
        }
        #line 39 "src/sampler/AliveParticleFilter.birch"
        x(n)->\u039e->pushBack(h->\u039e);
        #line 40 "src/sampler/AliveParticleFilter.birch"
        x(n)->\u03a6->pushBack(h->\u03a6);
        #line 41 "src/sampler/AliveParticleFilter.birch"
        w(n) = h->w;
        #line 42 "src/sampler/AliveParticleFilter.birch"
        if (!(isfinite(w(n)))) {
          #line 43 "src/sampler/AliveParticleFilter.birch"
          a(n) = birch::ancestor(w0);
        }
      } while (!(isfinite(w(n))));
    }
    #if HAVE_NUMBIRCH_HPP
    numbirch::wait();
    #endif
  }
  #line 50 "src/sampler/AliveParticleFilter.birch"
  w(simulate_uniform_int(1, nparticles)) = -(std::numeric_limits<Real>::infinity());
  #line 52 "src/sampler/AliveParticleFilter.birch"
  npropagations = sum(p);
  #line 53 "src/sampler/AliveParticleFilter.birch"
  std::tie(ess, lsum) = resample_reduce(w);
  #line 54 "src/sampler/AliveParticleFilter.birch"
  lnormalize = lnormalize + lsum - log(npropagations - 1);
}

#line 1 "src/sampler/AliveParticleFilter.birch"
Object_* make_AliveParticleFilter_() {
  #line 1 "src/sampler/AliveParticleFilter.birch"
  return new AliveParticleFilter_();
  #line 1 "src/sampler/AliveParticleFilter.birch"
}
static int register_factory_AliveParticleFilter_ = ::register_factory("AliveParticleFilter", make_AliveParticleFilter_);

}
namespace birch {
#line 18 "src/sampler/Kernel.birch"
Kernel_::Kernel_() :
    #line 18 "src/sampler/Kernel.birch"
    base_type_(),
    #line 22 "src/sampler/Kernel.birch"
    nlags(0),
    #line 27 "src/sampler/Kernel.birch"
    nmoves(1),
    #line 32 "src/sampler/Kernel.birch"
    scale(Real(1.0)),
    #line 37 "src/sampler/Kernel.birch"
    raccepts(Real(0.574)),
    #line 42 "src/sampler/Kernel.birch"
    Ki(Real(1.2)),
    #line 43 "src/sampler/Kernel.birch"
    Kp(Real(0.6)),
    #line 44 "src/sampler/Kernel.birch"
    Kd(Real(0.3)),
    #line 49 "src/sampler/Kernel.birch"
    e1(Real(0.0)),
    #line 50 "src/sampler/Kernel.birch"
    e2(Real(0.0)),
    #line 51 "src/sampler/Kernel.birch"
    e3(Real(0.0)) {
  //
}

#line 67 "src/sampler/Kernel.birch"
void Kernel_::adapt(const Real& raccepts) {
  #line 68 "src/sampler/Kernel.birch"
  e3 = e2;
  #line 69 "src/sampler/Kernel.birch"
  e2 = e1;
  #line 70 "src/sampler/Kernel.birch"
  e1 = raccepts - this->raccepts;
  #line 71 "src/sampler/Kernel.birch"
  scale = exp(log(scale) + (Ki + Kp + Kd) * e1 - (Kp + Real(2.0) * Kd) * e2 + Kd * e3);
}

#line 74 "src/sampler/Kernel.birch"
void Kernel_::read(const Buffer& buffer) {
  #line 75 "src/sampler/Kernel.birch"
  this->base_type_::read(buffer);
  #line 76 "src/sampler/Kernel.birch"
  birch::optional_assign(nlags, buffer->get<Integer>(String("nlags")));
  #line 77 "src/sampler/Kernel.birch"
  birch::optional_assign(nmoves, buffer->get<Integer>(String("nmoves")));
  #line 78 "src/sampler/Kernel.birch"
  birch::optional_assign(scale, buffer->get<Real>(String("scale")));
  #line 79 "src/sampler/Kernel.birch"
  birch::optional_assign(raccepts, buffer->get<Real>(String("raccepts")));
  #line 80 "src/sampler/Kernel.birch"
  birch::optional_assign(Ki, buffer->get<Real>(String("Ki")));
  #line 81 "src/sampler/Kernel.birch"
  birch::optional_assign(Kp, buffer->get<Real>(String("Kp")));
  #line 82 "src/sampler/Kernel.birch"
  birch::optional_assign(Kd, buffer->get<Real>(String("Kd")));
}

#line 85 "src/sampler/Kernel.birch"
void Kernel_::write(const Buffer& buffer) {
  #line 86 "src/sampler/Kernel.birch"
  this->base_type_::write(buffer);
  #line 87 "src/sampler/Kernel.birch"
  buffer->set(String("nlags"), nlags);
  #line 88 "src/sampler/Kernel.birch"
  buffer->set(String("nmoves"), nmoves);
  #line 89 "src/sampler/Kernel.birch"
  buffer->set(String("scale"), scale);
  #line 90 "src/sampler/Kernel.birch"
  buffer->set(String("raccepts"), raccepts);
  #line 91 "src/sampler/Kernel.birch"
  buffer->set(String("Ki"), Ki);
  #line 92 "src/sampler/Kernel.birch"
  buffer->set(String("Kp"), Kp);
  #line 93 "src/sampler/Kernel.birch"
  buffer->set(String("Kd"), Kd);
}

}
namespace birch {
#line 1 "src/sampler/LangevinKernel.birch"
LangevinKernel_::LangevinKernel_() :
    #line 1 "src/sampler/LangevinKernel.birch"
    base_type_() {
  //
}

#line 12 "src/sampler/LangevinKernel.birch"
Real LangevinKernel_::move(const Model& y) {
  auto naccepts = 0;
  #line 14 "src/sampler/LangevinKernel.birch"
  if (nmoves > 0) {
    #line 15 "src/sampler/LangevinKernel.birch"
    y->hoist();
    #line 16 "src/sampler/LangevinKernel.birch"
    if ((bool(y->\u03c0))) {
      auto \u03c0 = (*(y->\u03c0));
      #line 20 "src/sampler/LangevinKernel.birch"
      \u03c0->grad(Real(1.0));
      auto p = \u03c0->eval();
      auto n3237_ = \u03c0->args();
      auto x = std::move(std::get<0>(n3237_));
      auto g = std::move(std::get<1>(n3237_));
      auto m = length(x);
      auto \u03b4 = vector(scale, m);
      auto \u03bc = x + hadamard(g, \u03b4);
      auto accept = true;
      #line 29 "src/sampler/LangevinKernel.birch"
      for (int n = int(1); n <= int(nmoves); ++n) {
        auto z = standard_gaussian(m);
        auto p_prime_ = \u03c0->move(\u03bc + hadamard(sqrt(Real(2.0) * \u03b4), z));
        #line 33 "src/sampler/LangevinKernel.birch"
        \u03c0->grad(Real(1.0));
        auto n3238_ = \u03c0->args();
        auto x_prime_ = std::move(std::get<0>(n3238_));
        auto g_prime_ = std::move(std::get<1>(n3238_));
        auto \u03bc_prime_ = x_prime_ + hadamard(g_prime_, \u03b4);
        auto q = (pow(x - \u03bc_prime_, Real(2.0)) - pow(x_prime_ - \u03bc, Real(2.0))) / \u03b4;
        auto r = -(Real(0.25)) * sum(where(isfinite(q), q, Real(0.0)));
        #line 42 "src/sampler/LangevinKernel.birch"
        accept = log(simulate_uniform(Real(0.0), Real(1.0))) <= p_prime_ - p + r;
        #line 43 "src/sampler/LangevinKernel.birch"
        if (accept) {
          #line 44 "src/sampler/LangevinKernel.birch"
          naccepts = naccepts + 1;
          #line 45 "src/sampler/LangevinKernel.birch"
          p = p_prime_;
          #line 46 "src/sampler/LangevinKernel.birch"
          x = x_prime_;
          #line 47 "src/sampler/LangevinKernel.birch"
          g = g_prime_;
          #line 48 "src/sampler/LangevinKernel.birch"
          \u03bc = \u03bc_prime_;
        }
      }
      #line 51 "src/sampler/LangevinKernel.birch"
      if (!(accept)) {
        #line 52 "src/sampler/LangevinKernel.birch"
        \u03c0->move(x);
      }
      #line 56 "src/sampler/LangevinKernel.birch"
      y->\u03c0 = std::nullopt;
      #line 57 "src/sampler/LangevinKernel.birch"
      y->constant(nlags);
    }
  }
  #line 60 "src/sampler/LangevinKernel.birch"
  return cast<Real>(naccepts) / nmoves;
}

#line 1 "src/sampler/LangevinKernel.birch"
Object_* make_LangevinKernel_() {
  #line 1 "src/sampler/LangevinKernel.birch"
  return new LangevinKernel_();
  #line 1 "src/sampler/LangevinKernel.birch"
}
static int register_factory_LangevinKernel_ = ::register_factory("LangevinKernel", make_LangevinKernel_);

}
namespace birch {
#line 1 "src/sampler/ParticleFilter.birch"
ParticleFilter_::ParticleFilter_() :
    #line 1 "src/sampler/ParticleFilter.birch"
    base_type_(),
    #line 15 "src/sampler/ParticleFilter.birch"
    x(),
    #line 20 "src/sampler/ParticleFilter.birch"
    w(),
    #line 25 "src/sampler/ParticleFilter.birch"
    r(0),
    #line 30 "src/sampler/ParticleFilter.birch"
    lsum(Real(0.0)),
    #line 35 "src/sampler/ParticleFilter.birch"
    ess(Real(0.0)),
    #line 40 "src/sampler/ParticleFilter.birch"
    lnormalize(Real(0.0)),
    #line 48 "src/sampler/ParticleFilter.birch"
    npropagations(0),
    #line 53 "src/sampler/ParticleFilter.birch"
    raccepts(),
    #line 58 "src/sampler/ParticleFilter.birch"
    nparticles(1),
    #line 65 "src/sampler/ParticleFilter.birch"
    trigger(Real(0.7)),
    #line 70 "src/sampler/ParticleFilter.birch"
    autoconj(true),
    #line 75 "src/sampler/ParticleFilter.birch"
    autodiff(false),
    #line 80 "src/sampler/ParticleFilter.birch"
    autojoin(false) {
  //
}

#line 88 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::filter(const Model& model, const Buffer& input) {
  #line 89 "src/sampler/ParticleFilter.birch"
  x->clear();
  #line 90 "src/sampler/ParticleFilter.birch"
  birch::bridge(model);
  #line 91 "src/sampler/ParticleFilter.birch"
  for (int n = int(1); n <= int(nparticles); ++n) {
    #line 92 "src/sampler/ParticleFilter.birch"
    x->pushBack(birch::copy(model));
  }
  #line 94 "src/sampler/ParticleFilter.birch"
  w = vector(Real(0.0), nparticles);
  #line 95 "src/sampler/ParticleFilter.birch"
  r = 0;
  #line 96 "src/sampler/ParticleFilter.birch"
  ess = nparticles;
  #line 97 "src/sampler/ParticleFilter.birch"
  lsum = Real(0.0);
  #line 98 "src/sampler/ParticleFilter.birch"
  lnormalize = Real(0.0);
  #line 99 "src/sampler/ParticleFilter.birch"
  npropagations = nparticles;
  #line 100 "src/sampler/ParticleFilter.birch"
  simulate(input);
}

#line 110 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::filter(const Integer& t, const Buffer& input, const std::optional<Kernel>& \u03ba) {
  #line 111 "src/sampler/ParticleFilter.birch"
  resample(t, \u03ba);
  #line 112 "src/sampler/ParticleFilter.birch"
  simulate(t, input);
}

#line 121 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::filter(const Integer& t, const Buffer& input) {
  #line 122 "src/sampler/ParticleFilter.birch"
  filter(t, input, std::nullopt);
}

#line 130 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::simulate(const Buffer& input) {
  #line 131 "src/sampler/ParticleFilter.birch"
  #if HAVE_NUMBIRCH_HPP
  numbirch::wait();
  #endif
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (int n = int(1); n <= int(nparticles); ++n) {
      auto h = construct<Handler>(autoconj, autodiff, autojoin);
      #line 133 "src/sampler/ParticleFilter.birch"
      {
        auto handler_ = swap_handler(h);
        #line 134 "src/sampler/ParticleFilter.birch"
        x(n)->read(input);
        #line 135 "src/sampler/ParticleFilter.birch"
        x(n)->simulate();
        set_handler(handler_);
      }
      #line 137 "src/sampler/ParticleFilter.birch"
      x(n)->\u039e->pushBack(h->\u039e);
      #line 138 "src/sampler/ParticleFilter.birch"
      x(n)->\u03a6->pushBack(h->\u03a6);
      #line 139 "src/sampler/ParticleFilter.birch"

      w.slice(n) = w.slice(n) + h->w;
          }
    #if HAVE_NUMBIRCH_HPP
    numbirch::wait();
    #endif
  }
  #line 143 "src/sampler/ParticleFilter.birch"
  std::tie(ess, lsum) = resample_reduce(w);
  #line 144 "src/sampler/ParticleFilter.birch"
  lnormalize = lnormalize + lsum - log(nparticles);
  #line 145 "src/sampler/ParticleFilter.birch"
  npropagations = nparticles;
}

#line 154 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::simulate(const Integer& t, const Buffer& input) {
  #line 155 "src/sampler/ParticleFilter.birch"
  #if HAVE_NUMBIRCH_HPP
  numbirch::wait();
  #endif
  #pragma omp parallel
  {
    #pragma omp for schedule(static)
    for (int n = int(1); n <= int(nparticles); ++n) {
      auto h = construct<Handler>(autoconj, autodiff, autojoin);
      #line 157 "src/sampler/ParticleFilter.birch"
      {
        auto handler_ = swap_handler(h);
        #line 158 "src/sampler/ParticleFilter.birch"
        x(n)->read(t, input);
        #line 159 "src/sampler/ParticleFilter.birch"
        x(n)->simulate(t);
        set_handler(handler_);
      }
      #line 161 "src/sampler/ParticleFilter.birch"
      x(n)->\u039e->pushBack(h->\u039e);
      #line 162 "src/sampler/ParticleFilter.birch"
      x(n)->\u03a6->pushBack(h->\u03a6);
      #line 163 "src/sampler/ParticleFilter.birch"

      w.slice(n) = w.slice(n) + h->w;
          }
    #if HAVE_NUMBIRCH_HPP
    numbirch::wait();
    #endif
  }
  #line 167 "src/sampler/ParticleFilter.birch"
  std::tie(ess, lsum) = resample_reduce(w);
  #line 168 "src/sampler/ParticleFilter.birch"
  lnormalize = lnormalize + lsum - log(nparticles);
  #line 169 "src/sampler/ParticleFilter.birch"
  npropagations = nparticles;
}

#line 178 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::resample(const Integer& t, const std::optional<Kernel>& \u03ba) {
  #line 179 "src/sampler/ParticleFilter.birch"
  if (r < t) {
    #line 180 "src/sampler/ParticleFilter.birch"
    r = t;
    #line 181 "src/sampler/ParticleFilter.birch"
    raccepts = std::nullopt;
    #line 182 "src/sampler/ParticleFilter.birch"
    if (ess <= trigger * nparticles) {
      auto n3239_ = resample_systematic(w);
      auto a = std::move(std::get<0>(n3239_));
      auto o = std::move(std::get<1>(n3239_));
      #line 187 "src/sampler/ParticleFilter.birch"
      #if HAVE_NUMBIRCH_HPP
      numbirch::wait();
      #endif
      #pragma omp parallel
      {
        #pragma omp for schedule(guided)
        for (int n = int(1); n <= int(nparticles); ++n) {
          #line 188 "src/sampler/ParticleFilter.birch"
          if (o(n) >= 2) {
            #line 190 "src/sampler/ParticleFilter.birch"
            bridge(x(n));
          }
        }
        #if HAVE_NUMBIRCH_HPP
        numbirch::wait();
        #endif
      }
      #line 195 "src/sampler/ParticleFilter.birch"
      #if HAVE_NUMBIRCH_HPP
      numbirch::wait();
      #endif
      #pragma omp parallel
      {
        #pragma omp for schedule(guided)
        for (int n = int(1); n <= int(nparticles); ++n) {
          #line 196 "src/sampler/ParticleFilter.birch"
          if (a(n) != n) {
            #line 198 "src/sampler/ParticleFilter.birch"
            x(n) = copy(x(a(n)));
          }
        }
        #if HAVE_NUMBIRCH_HPP
        numbirch::wait();
        #endif
      }
      #line 203 "src/sampler/ParticleFilter.birch"
      collect();
      #line 206 "src/sampler/ParticleFilter.birch"
      if ((bool(\u03ba))) {
        auto \u03b1 = vector(Real(0.0), nparticles);
        #line 208 "src/sampler/ParticleFilter.birch"
        #if HAVE_NUMBIRCH_HPP
        numbirch::wait();
        #endif
        #pragma omp parallel
        {
          #pragma omp for schedule(static)
          for (int n = int(1); n <= int(nparticles); ++n) {
            #line 209 "src/sampler/ParticleFilter.birch"
            \u03b1(n) = (*(\u03ba))->move(x(n));
          }
          #if HAVE_NUMBIRCH_HPP
          numbirch::wait();
          #endif
        }
        #line 211 "src/sampler/ParticleFilter.birch"
        raccepts = sum(\u03b1) / nparticles;
        #line 214 "src/sampler/ParticleFilter.birch"
        (*(\u03ba))->adapt((*(raccepts)));
      }
      #line 218 "src/sampler/ParticleFilter.birch"
      w = vector(Real(0.0), nparticles);
    } else {
      #line 221 "src/sampler/ParticleFilter.birch"
      w = w - (lsum - log(nparticles));
      #line 222 "src/sampler/ParticleFilter.birch"
      collect();
    }
  }
}

#line 234 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::reconfigure(const Boolean& autoconj, const Boolean& autodiff, const Boolean& autojoin) {
  #line 235 "src/sampler/ParticleFilter.birch"
  this->autoconj = autoconj;
  #line 236 "src/sampler/ParticleFilter.birch"
  this->autodiff = autodiff;
  #line 237 "src/sampler/ParticleFilter.birch"
  this->autojoin = autojoin;
}

#line 240 "src/sampler/ParticleFilter.birch"
void ParticleFilter_::read(const Buffer& buffer) {
  #line 241 "src/sampler/ParticleFilter.birch"
  birch::optional_assign(nparticles, buffer->get<Integer>(String("nparticles")));
  #line 242 "src/sampler/ParticleFilter.birch"
  birch::optional_assign(trigger, buffer->get<Real>(String("trigger")));
  #line 243 "src/sampler/ParticleFilter.birch"
  birch::optional_assign(autoconj, buffer->get<Boolean>(String("autoconj")));
  #line 244 "src/sampler/ParticleFilter.birch"
  birch::optional_assign(autodiff, buffer->get<Boolean>(String("autodiff")));
  #line 245 "src/sampler/ParticleFilter.birch"
  birch::optional_assign(autojoin, buffer->get<Boolean>(String("autojoin")));
}

#line 1 "src/sampler/ParticleFilter.birch"
Object_* make_ParticleFilter_() {
  #line 1 "src/sampler/ParticleFilter.birch"
  return new ParticleFilter_();
  #line 1 "src/sampler/ParticleFilter.birch"
}
static int register_factory_ParticleFilter_ = ::register_factory("ParticleFilter", make_ParticleFilter_);

}
namespace birch {
#line 1 "src/sampler/ParticleSampler.birch"
ParticleSampler_::ParticleSampler_() :
    #line 1 "src/sampler/ParticleSampler.birch"
    base_type_() {
  //
}

#line 12 "src/sampler/ParticleSampler.birch"
void ParticleSampler_::sample(const ParticleFilter& filter, const Model& model, const Buffer& input) {
  #line 13 "src/sampler/ParticleSampler.birch"
  filter->filter(model, input);
}

#line 23 "src/sampler/ParticleSampler.birch"
void ParticleSampler_::sample(const ParticleFilter& filter, const Integer& t, const Buffer& input) {
  #line 24 "src/sampler/ParticleSampler.birch"
  filter->filter(t, input);
}

#line 35 "src/sampler/ParticleSampler.birch"
void ParticleSampler_::sample(const ParticleFilter& filter, const Integer& t, const Buffer& input, const Kernel& \u03ba) {
  #line 36 "src/sampler/ParticleSampler.birch"
  filter->filter(t, input, \u03ba);
}

#line 42 "src/sampler/ParticleSampler.birch"
std::tuple<Model, Real> ParticleSampler_::draw(const ParticleFilter& filter) {
  auto b = ancestor(filter->w);
  #line 44 "src/sampler/ParticleSampler.birch"
  if (b == 0) {
    #line 45 "src/sampler/ParticleSampler.birch"
    error(String("particle filter degenerated"));
  }
  #line 47 "src/sampler/ParticleSampler.birch"
  return std::make_tuple(filter->x(b), filter->lnormalize);
}

#line 1 "src/sampler/ParticleSampler.birch"
Object_* make_ParticleSampler_() {
  #line 1 "src/sampler/ParticleSampler.birch"
  return new ParticleSampler_();
  #line 1 "src/sampler/ParticleSampler.birch"
}
static int register_factory_ParticleSampler_ = ::register_factory("ParticleSampler", make_ParticleSampler_);

}
