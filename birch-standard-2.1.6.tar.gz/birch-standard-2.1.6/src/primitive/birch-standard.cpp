#line 1 "src/primitive/chrono.birch"

#include <chrono>

thread_local static std::chrono::time_point<std::chrono::steady_clock>
    savedTimePoint = std::chrono::steady_clock::now();
namespace birch {

/**
 * Reset timer.
 */
#line 11 "src/primitive/chrono.birch"
void tic() {
  #line 12 "src/primitive/chrono.birch"

  savedTimePoint = std::chrono::steady_clock::now();
  }


/**
 * Number of seconds since last call to `tic()`.
 */
#line 20 "src/primitive/chrono.birch"
Real toc() {
  Real elapsed;
  #line 22 "src/primitive/chrono.birch"

  std::chrono::duration<Real> e = std::chrono::steady_clock::now() -
      savedTimePoint;
  elapsed = e.count();
    #line 27 "src/primitive/chrono.birch"
  return elapsed;
}

}
namespace birch {

/**
 * Run the cycle collector.
 */
#line 4 "src/primitive/collect.birch"
void collect() {
  #line 5 "src/primitive/collect.birch"

  membirch::collect();
  }

}
namespace birch {

/**
 * Output an error message and exit.
 *
 * @param msg The message.
 */
#line 6 "src/primitive/error.birch"
void error(const String& msg) {
  #line 7 "src/primitive/error.birch"
  stderr_->print(String("error: ") + msg + String("\n"));
  #line 8 "src/primitive/error.birch"

  std::exit(EXIT_FAILURE);
  }


/**
 * Output a warning message.
 */
#line 16 "src/primitive/error.birch"
void warn(const String& msg) {
  #line 17 "src/primitive/error.birch"
  stderr_->print(String("warning: ") + msg + String("\n"));
}

}
#line 1 "src/primitive/filesystem.birch"

#if defined(HAVE_FILESYSTEM)
#include <filesystem>
namespace fs = std::filesystem;
#elif defined(HAVE_EXPERIMENTAL_FILESYSTEM)
#include <experimental/filesystem>
namespace fs = std::experimental::filesystem;
#else
#include <boost/filesystem.hpp>
namespace fs = boost::filesystem;
#endif
namespace birch {
#line 14 "src/primitive/filesystem.birch"
Integer READ = 1;
#line 15 "src/primitive/filesystem.birch"
Integer WRITE = 2;
#line 16 "src/primitive/filesystem.birch"
Integer APPEND = 3;

/**
 * Create a directory.
 *
 * @param path Path of the directory, or path of a file in the directory.
 */
#line 23 "src/primitive/filesystem.birch"
void mkdir(const String& path) {
  #line 24 "src/primitive/filesystem.birch"

  fs::path p = path;
  if (!fs::is_directory(p)) {
    p = p.parent_path();
  }
  fs::create_directories(p);
  }


/**
 * Open a file for reading.
 *
 * @param path Path of the file.
 *
 * @return File handle.
 *
 * If `path` includes non-existing directory, that directory is created (if
 * possible). The file is locked for reading (if possible).
 */
#line 43 "src/primitive/filesystem.birch"
File fopen(const String& path) {
  #line 44 "src/primitive/filesystem.birch"
  return fopen(path, READ);
}


/**
 * Open a file.
 *
 * @param path Path of the file.
 * @param mode The mode, either `READ`, `WRITE`, or `APPEND`.
 *
 * @return File handle.
 *
 * If `path` includes non-existing directory, that directory is created (if
 * possible). The file is locked for reading or writing as appropriate (if
 * possible).
 */
#line 59 "src/primitive/filesystem.birch"
File fopen(const String& path, const Integer& mode) {
  #line 60 "src/primitive/filesystem.birch"
  assert(mode == READ || mode == WRITE || mode == APPEND);
  String s;
  #line 62 "src/primitive/filesystem.birch"
  if (mode == READ) {
    #line 63 "src/primitive/filesystem.birch"
    s = String("r");
  } else {
    #line 64 "src/primitive/filesystem.birch"
    if (mode == WRITE) {
      #line 65 "src/primitive/filesystem.birch"
      s = String("w");
      #line 66 "src/primitive/filesystem.birch"

    fs::path p = path;
    if (!p.parent_path().empty()) {
      fs::create_directories(p.parent_path());
    }
        } else {
      #line 72 "src/primitive/filesystem.birch"
      if (mode == APPEND) {
        #line 73 "src/primitive/filesystem.birch"
        s = String("a");
      }
    }
  }
  #line 75 "src/primitive/filesystem.birch"

  auto f = ::fopen(path.c_str(), s.c_str());
  if (!f) {
    error("could not open file " + path + ".");
  }
  lockf(fileno(f), F_LOCK, 0);
  return f;
  }


/**
 * File extension of a path.
 */
#line 88 "src/primitive/filesystem.birch"
String extension(const String& path) {
  String ext;
  #line 90 "src/primitive/filesystem.birch"

  fs::path f(path);
  ext = f.extension().string();
    #line 94 "src/primitive/filesystem.birch"
  return ext;
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 4 "src/primitive/resample.birch"
Real nan_exp(const Real& x) {
  #line 5 "src/primitive/resample.birch"
  if (isnan(x)) {
    #line 6 "src/primitive/resample.birch"
    return Real(0.0);
  } else {
    #line 8 "src/primitive/resample.birch"
    return exp(x);
  }
}

#line 15 "src/primitive/resample.birch"
Real nan_max(const Real& x, const Real& y) {
  #line 16 "src/primitive/resample.birch"
  if (isnan(x) && isnan(y)) {
    #line 17 "src/primitive/resample.birch"
    return -(std::numeric_limits<Real>::infinity());
  } else {
    #line 18 "src/primitive/resample.birch"
    if (isnan(x)) {
      #line 19 "src/primitive/resample.birch"
      return y;
    } else {
      #line 20 "src/primitive/resample.birch"
      if (isnan(y)) {
        #line 21 "src/primitive/resample.birch"
        return x;
      } else {
        #line 23 "src/primitive/resample.birch"
        return max(x, y);
      }
    }
  }
}

#line 31 "src/primitive/resample.birch"
Real nan_max(const numbirch::Array<Real,1>& w) {
  #line 32 "src/primitive/resample.birch"
  return reduce(w, -(std::numeric_limits<Real>::infinity()), [=](const Real& x, const Real& y) {
    #line 32 "src/primitive/resample.birch"
    return nan_max(x, y);
  });
}

#line 52 "src/primitive/resample.birch"
Real log_sum_exp(const numbirch::Array<Real,1>& w) {
  #line 53 "src/primitive/resample.birch"
  if (length(w) > 0) {
    auto mx = -(std::numeric_limits<Real>::infinity());
    auto r = Real(0.0);
    #line 62 "src/primitive/resample.birch"
    for (int n = int(1); n <= int(length(w)); ++n) {
      auto wn = w(n);
      #line 64 "src/primitive/resample.birch"
      if (wn == std::numeric_limits<Real>::infinity()) {
        #line 65 "src/primitive/resample.birch"
        return std::numeric_limits<Real>::infinity();
      } else {
        #line 66 "src/primitive/resample.birch"
        if (wn > mx) {
          #line 67 "src/primitive/resample.birch"
          r = (r + Real(1.0)) * exp(mx - wn);
          #line 68 "src/primitive/resample.birch"
          mx = wn;
        } else {
          #line 69 "src/primitive/resample.birch"
          if (isfinite(wn)) {
            #line 70 "src/primitive/resample.birch"
            r = r + exp(wn - mx);
          }
        }
      }
    }
    #line 73 "src/primitive/resample.birch"
    return mx + log1p(r);
  } else {
    #line 75 "src/primitive/resample.birch"
    return -(std::numeric_limits<Real>::infinity());
  }
}

#line 89 "src/primitive/resample.birch"
numbirch::Array<Real,1> norm_exp(const numbirch::Array<Real,1>& w) {
  #line 90 "src/primitive/resample.birch"
  if (length(w) == 0) {
    #line 91 "src/primitive/resample.birch"
    return w;
  } else {
    auto W = log_sum_exp(w);
    #line 94 "src/primitive/resample.birch"
    return transform(w, [=](const Real& x) {
      #line 94 "src/primitive/resample.birch"
      return nan_exp(x - W);
    });
  }
}

#line 111 "src/primitive/resample.birch"
std::tuple<numbirch::Array<Integer,1>, numbirch::Array<Integer,1>> resample_systematic(const numbirch::Array<Real,1>& w) {
  auto O = systematic_cumulative_offspring(cumulative_weights(w));
  auto a = permute_ancestors(cumulative_offspring_to_ancestors(O));
  auto o = cumulative_offspring_to_offspring(O);
  #line 115 "src/primitive/resample.birch"
  return std::make_tuple(a, o);
}

#line 128 "src/primitive/resample.birch"
numbirch::Array<Integer,1> resample_multinomial(const numbirch::Array<Real,1>& w) {
  #line 129 "src/primitive/resample.birch"
  return offspring_to_ancestors(simulate_multinomial(length(w), norm_exp(w)));
}

#line 143 "src/primitive/resample.birch"
Integer cumulative_ancestor(const numbirch::Array<Real,1>& W) {
  auto n = 0;
  auto N = length(W);
  #line 146 "src/primitive/resample.birch"
  if (N > 0 && W(N) > Real(0.0)) {
    auto u = simulate_uniform(Real(0.0), W(N));
    auto l = 0;
    auto r = N;
    #line 151 "src/primitive/resample.birch"
    while (l < r) {
      #line 152 "src/primitive/resample.birch"
      n = (l + r) / 2;
      #line 153 "src/primitive/resample.birch"
      if (W(n + 1) < u) {
        #line 154 "src/primitive/resample.birch"
        l = n + 1;
      } else {
        #line 156 "src/primitive/resample.birch"
        r = n;
      }
    }
    #line 159 "src/primitive/resample.birch"
    n = l + 1;
  }
  #line 161 "src/primitive/resample.birch"
  assert(n <= N);
  #line 162 "src/primitive/resample.birch"
  return n;
}

#line 175 "src/primitive/resample.birch"
Integer ancestor(const numbirch::Array<Real,1>& w) {
  #line 176 "src/primitive/resample.birch"
  return cumulative_ancestor(cumulative_weights(w));
}

#line 182 "src/primitive/resample.birch"
numbirch::Array<Integer,1> systematic_cumulative_offspring(const numbirch::Array<Real,1>& W) {
  auto N = length(W);
  numbirch::Array<Integer,1> O(numbirch::make_shape(N));
  auto u = simulate_uniform(Real(0.0), Real(1.0));
  #line 186 "src/primitive/resample.birch"
  for (int n = int(1); n <= int(N); ++n) {
    auto r = N * W(n) / W(N);
    #line 188 "src/primitive/resample.birch"
    O(n) = min(N, cast<Integer>(r + u));
  }
  #line 190 "src/primitive/resample.birch"
  return O;
}

#line 196 "src/primitive/resample.birch"
numbirch::Array<Integer,1> offspring_to_ancestors(const numbirch::Array<Integer,1>& o) {
  auto N = length(o);
  auto i = 1;
  numbirch::Array<Integer,1> a(numbirch::make_shape(N));
  #line 200 "src/primitive/resample.birch"
  for (int n = int(1); n <= int(N); ++n) {
    #line 201 "src/primitive/resample.birch"
    for (int j = int(1); j <= int(o(n)); ++j) {
      #line 202 "src/primitive/resample.birch"
      a(i) = n;
      #line 203 "src/primitive/resample.birch"
      i = i + 1;
    }
  }
  #line 206 "src/primitive/resample.birch"
  assert(i == N + 1);
  #line 207 "src/primitive/resample.birch"
  assert(is_sorted(a));
  #line 208 "src/primitive/resample.birch"
  return a;
}

#line 214 "src/primitive/resample.birch"
numbirch::Array<Integer,1> cumulative_offspring_to_ancestors(const numbirch::Array<Integer,1>& O) {
  auto N = length(O);
  numbirch::Array<Integer,1> a(numbirch::make_shape(N));
  #line 217 "src/primitive/resample.birch"
  for (int n = int(1); n <= int(N); ++n) {
    auto start = 0;
    #line 219 "src/primitive/resample.birch"
    if (n > 1) {
      #line 220 "src/primitive/resample.birch"
      start = O(n - 1);
    }
    auto o = O(n) - start;
    #line 223 "src/primitive/resample.birch"
    for (int j = int(1); j <= int(o); ++j) {
      #line 224 "src/primitive/resample.birch"
      a(start + j) = n;
    }
  }
  #line 227 "src/primitive/resample.birch"
  assert(is_sorted(a));
  #line 228 "src/primitive/resample.birch"
  return a;
}

#line 234 "src/primitive/resample.birch"
numbirch::Array<Integer,1> cumulative_offspring_to_offspring(const numbirch::Array<Integer,1>& O) {
  #line 235 "src/primitive/resample.birch"
  return adjacent_difference(O, [=](const Integer& x, const Integer& y) -> Integer {
    #line 236 "src/primitive/resample.birch"
    return x - y;
  });
}

#line 244 "src/primitive/resample.birch"
numbirch::Array<Integer,1> permute_ancestors(const numbirch::Array<Integer,1>& a) {
  auto N = length(a);
  auto b = a;
  auto n = 1;
  #line 248 "src/primitive/resample.birch"
  while (n <= N) {
    auto c = b(n);
    #line 250 "src/primitive/resample.birch"
    if (c != n && b(c) != c) {
      #line 251 "src/primitive/resample.birch"
      b(n) = b(c);
      #line 252 "src/primitive/resample.birch"
      b(c) = c;
    } else {
      #line 254 "src/primitive/resample.birch"
      n = n + 1;
    }
  }
  #line 257 "src/primitive/resample.birch"
  return b;
}

#line 263 "src/primitive/resample.birch"
numbirch::Array<Real,1> cumulative_weights(const numbirch::Array<Real,1>& w) {
  auto N = length(w);
  numbirch::Array<Real,1> W(numbirch::make_shape(N));
  #line 266 "src/primitive/resample.birch"
  if (N > 0) {
    auto mx = nan_max(w);
    #line 268 "src/primitive/resample.birch"
    W(1) = nan_exp(w(1) - mx);
    #line 269 "src/primitive/resample.birch"
    for (int n = int(2); n <= int(N); ++n) {
      #line 270 "src/primitive/resample.birch"
      W(n) = W(n - 1) + nan_exp(w(n) - mx);
    }
  }
  #line 273 "src/primitive/resample.birch"
  return W;
}

#line 293 "src/primitive/resample.birch"
std::tuple<Real, Real> resample_reduce(const numbirch::Array<Real,1>& w) {
  #line 294 "src/primitive/resample.birch"
  if (length(w) == 0) {
    #line 295 "src/primitive/resample.birch"
    return std::make_tuple(Real(0.0), -(std::numeric_limits<Real>::infinity()));
  } else {
    auto mx = -(std::numeric_limits<Real>::infinity());
    auto r = Real(0.0);
    auto q = Real(0.0);
    #line 307 "src/primitive/resample.birch"
    for (int n = int(1); n <= int(length(w)); ++n) {
      auto wn = w(n);
      #line 309 "src/primitive/resample.birch"
      if (wn == std::numeric_limits<Real>::infinity()) {
        #line 310 "src/primitive/resample.birch"
        return std::make_tuple(Real(1.0), std::numeric_limits<Real>::infinity());
      } else {
        #line 311 "src/primitive/resample.birch"
        if (wn > mx) {
          auto v = exp(mx - wn);
          #line 313 "src/primitive/resample.birch"
          r = (r + Real(1.0)) * v;
          #line 314 "src/primitive/resample.birch"
          q = (q + Real(1.0)) * v * v;
          #line 315 "src/primitive/resample.birch"
          mx = wn;
        } else {
          #line 316 "src/primitive/resample.birch"
          if (isfinite(wn)) {
            auto v = exp(wn - mx);
            #line 318 "src/primitive/resample.birch"
            r = r + v;
            #line 319 "src/primitive/resample.birch"
            q = q + v * v;
          }
        }
      }
    }
    #line 324 "src/primitive/resample.birch"
    if (mx == -(std::numeric_limits<Real>::infinity())) {
      #line 325 "src/primitive/resample.birch"
      return std::make_tuple(Real(0.0), -(std::numeric_limits<Real>::infinity()));
    }
    auto log_sum_weights = mx + log1p(r);
    auto rp1 = r + Real(1.0);
    auto ess = rp1 * rp1 / (q + Real(1.0));
    #line 332 "src/primitive/resample.birch"
    return std::make_tuple(ess, log_sum_weights);
  }
}

}
namespace birch {
#line 4 "src/primitive/stdio.birch"
File getStdIn() {
  #line 5 "src/primitive/stdio.birch"

  return stdin;
  }

#line 13 "src/primitive/stdio.birch"
File getStdOut() {
  #line 14 "src/primitive/stdio.birch"

  return stdout;
  }

#line 22 "src/primitive/stdio.birch"
File getStdErr() {
  #line 23 "src/primitive/stdio.birch"

  return stderr;
  }


/**
 * Input stream for stdin.
 */
#line 31 "src/primitive/stdio.birch"
InputStream stdin_ = make_input_stream(getStdIn());

/**
 * Output stream for stdout.
 */
#line 36 "src/primitive/stdio.birch"
OutputStream stdout_ = make_output_stream(getStdOut());

/**
 * Output stream for stderr.
 */
#line 41 "src/primitive/stdio.birch"
OutputStream stderr_ = make_output_stream(getStdErr());
}
namespace birch {
}
