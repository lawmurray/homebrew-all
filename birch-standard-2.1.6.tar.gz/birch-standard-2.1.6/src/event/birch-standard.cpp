namespace birch {
#line 30 "src/event/Handler.birch"
Handler_::Handler_(const Boolean& autoconj, const Boolean& autodiff, const Boolean& autojoin) :
    #line 30 "src/event/Handler.birch"
    base_type_(),
    #line 34 "src/event/Handler.birch"
    \u039e(),
    #line 39 "src/event/Handler.birch"
    \u03a6(),
    #line 44 "src/event/Handler.birch"
    w(Real(0.0)),
    #line 49 "src/event/Handler.birch"
    autoconj(autoconj),
    #line 54 "src/event/Handler.birch"
    autodiff(autodiff),
    #line 59 "src/event/Handler.birch"
    autojoin(autojoin && autodiff) {
  //
}

#line 61 "src/event/Handler.birch"
std::optional<Expression<Real>> Handler_::hoist() {
  std::optional<Expression<Real>> \u03c0;
  #line 63 "src/event/Handler.birch"
  for (int i = int(1); i <= int(\u039e->size()); ++i) {
    auto \u03be = \u039e(i)->hoist();
    #line 65 "src/event/Handler.birch"
    if ((bool(\u03be))) {
      #line 66 "src/event/Handler.birch"
      if ((bool(\u03c0))) {
        #line 67 "src/event/Handler.birch"
        \u03c0 = box((*(\u03c0)) + (*(\u03be)));
      } else {
        #line 69 "src/event/Handler.birch"
        \u03c0 = (*(\u03be));
      }
    }
  }
  #line 73 "src/event/Handler.birch"
  for (int i = int(1); i <= int(\u03a6->size()); ++i) {
    auto \u03c6 = \u03a6(i);
    #line 75 "src/event/Handler.birch"
    if ((bool(\u03c0))) {
      #line 76 "src/event/Handler.birch"
      \u03c0 = box((*(\u03c0)) + \u03c6);
    } else {
      #line 78 "src/event/Handler.birch"
      \u03c0 = \u03c6;
    }
  }
  #line 81 "src/event/Handler.birch"
  return \u03c0;
}

#line 247 "src/event/Handler.birch"
void Handler_::handleFactor(const Real& \u03c6) {
  #line 248 "src/event/Handler.birch"
  w = w + \u03c6;
}

#line 258 "src/event/Handler.birch"
void Handler_::handleFactor(const numbirch::Future<Real>& \u03c6) {
  #line 259 "src/event/Handler.birch"
  w = w + \u03c6;
}

}
#line 1 "src/event/handle.birch"

/*
 * Event handler for each thread.
 */
static thread_local birch::Handler handler(nullptr);
namespace birch {

/**
 * Initialize.
 */
#line 11 "src/event/handle.birch"
void init() {
  #line 12 "src/event/handle.birch"

  #pragma omp parallel
  {
    handler = birch::Handler(std::in_place, true, false, false);
  }
  }


/**
 * Terminate.
 */
#line 23 "src/event/handle.birch"
void term() {
  #line 24 "src/event/handle.birch"

  #pragma omp parallel
  {
    handler.release();
  }
  }

#line 35 "src/event/handle.birch"
Handler get_handler() {
  #line 36 "src/event/handle.birch"

  return ::handler;
  }

#line 49 "src/event/handle.birch"
void set_handler(const Handler& handler) {
  #line 50 "src/event/handle.birch"

  ::handler = handler;
  }

#line 67 "src/event/handle.birch"
Handler swap_handler(const Handler& handler) {
  #line 68 "src/event/handle.birch"

  auto& current = ::handler;
  auto previous = handler;
  std::swap(current, previous);
  return previous;
  }

}
