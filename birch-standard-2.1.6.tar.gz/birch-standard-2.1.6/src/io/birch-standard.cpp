namespace birch {
#line 7 "src/io/ArrayBufferIterator.birch"
ArrayBufferIterator_::ArrayBufferIterator_(const Array<Buffer>& values) :
    #line 7 "src/io/ArrayBufferIterator.birch"
    base_type_(),
    #line 11 "src/io/ArrayBufferIterator.birch"
    values(values),
    #line 16 "src/io/ArrayBufferIterator.birch"
    i(0) {
  //
}

#line 21 "src/io/ArrayBufferIterator.birch"
Boolean ArrayBufferIterator_::hasNext() {
  #line 22 "src/io/ArrayBufferIterator.birch"
  return i < values->size();
}

#line 28 "src/io/ArrayBufferIterator.birch"
Buffer ArrayBufferIterator_::next() {
  #line 29 "src/io/ArrayBufferIterator.birch"
  i = i + 1;
  #line 30 "src/io/ArrayBufferIterator.birch"
  return values(i);
}

}
namespace birch {
#line 24 "src/io/Buffer.birch"
Buffer_::Buffer_() :
    #line 24 "src/io/Buffer.birch"
    base_type_(),
    #line 44 "src/io/Buffer.birch"
    keys(),
    #line 45 "src/io/Buffer.birch"
    values(),
    #line 46 "src/io/Buffer.birch"
    scalarString(),
    #line 47 "src/io/Buffer.birch"
    scalarReal(),
    #line 48 "src/io/Buffer.birch"
    scalarInteger(),
    #line 49 "src/io/Buffer.birch"
    scalarBoolean(),
    #line 50 "src/io/Buffer.birch"
    vectorReal(),
    #line 51 "src/io/Buffer.birch"
    vectorInteger(),
    #line 52 "src/io/Buffer.birch"
    vectorBoolean(),
    #line 53 "src/io/Buffer.birch"
    matrixReal(),
    #line 54 "src/io/Buffer.birch"
    matrixInteger(),
    #line 55 "src/io/Buffer.birch"
    matrixBoolean() {
  //
}

#line 70 "src/io/Buffer.birch"
Boolean Buffer_::isNil() {
  #line 71 "src/io/Buffer.birch"
  return !(((bool(keys)) || (bool(values)) || (bool(scalarString)) || (bool(scalarReal)) || (bool(scalarInteger)) || (bool(scalarBoolean)) || (bool(vectorReal)) || (bool(vectorInteger)) || (bool(vectorBoolean)) || (bool(matrixReal)) || (bool(matrixInteger)) || (bool(matrixBoolean))));
}

#line 80 "src/io/Buffer.birch"
Boolean Buffer_::isNil(const String& key) {
  auto buffer = get(key);
  #line 82 "src/io/Buffer.birch"
  if ((bool(buffer))) {
    #line 83 "src/io/Buffer.birch"
    return (*(buffer))->isNil();
  } else {
    #line 85 "src/io/Buffer.birch"
    return true;
  }
}

#line 92 "src/io/Buffer.birch"
void Buffer_::setNil() {
  #line 93 "src/io/Buffer.birch"
  keys = std::nullopt;
  #line 94 "src/io/Buffer.birch"
  values = std::nullopt;
  #line 95 "src/io/Buffer.birch"
  scalarString = std::nullopt;
  #line 96 "src/io/Buffer.birch"
  scalarReal = std::nullopt;
  #line 97 "src/io/Buffer.birch"
  scalarInteger = std::nullopt;
  #line 98 "src/io/Buffer.birch"
  scalarBoolean = std::nullopt;
  #line 99 "src/io/Buffer.birch"
  vectorReal = std::nullopt;
  #line 100 "src/io/Buffer.birch"
  vectorInteger = std::nullopt;
  #line 101 "src/io/Buffer.birch"
  vectorBoolean = std::nullopt;
  #line 102 "src/io/Buffer.birch"
  matrixReal = std::nullopt;
  #line 103 "src/io/Buffer.birch"
  matrixInteger = std::nullopt;
  #line 104 "src/io/Buffer.birch"
  matrixBoolean = std::nullopt;
  #line 105 "src/io/Buffer.birch"

    map.clear();
    }

#line 113 "src/io/Buffer.birch"
void Buffer_::setNil(const String& key) {
  auto value = make_buffer();
  #line 115 "src/io/Buffer.birch"
  value->setNil();
  #line 116 "src/io/Buffer.birch"
  set(key, value);
}

#line 123 "src/io/Buffer.birch"
Boolean Buffer_::isEmpty() {
  #line 124 "src/io/Buffer.birch"
  return isNil() || ((bool(values)) && (*(values))->empty());
}

#line 131 "src/io/Buffer.birch"
Boolean Buffer_::isEmpty(const String& key) {
  auto buffer = get(key);
  #line 133 "src/io/Buffer.birch"
  if ((bool(buffer))) {
    #line 134 "src/io/Buffer.birch"
    return (*(buffer))->isEmpty();
  } else {
    #line 136 "src/io/Buffer.birch"
    return true;
  }
}

#line 143 "src/io/Buffer.birch"
void Buffer_::setEmptyObject() {
  #line 144 "src/io/Buffer.birch"
  setNil();
  #line 145 "src/io/Buffer.birch"
  keys = construct<Array<String>>();
  #line 146 "src/io/Buffer.birch"
  values = construct<Array<Buffer>>();
  #line 147 "src/io/Buffer.birch"

    map.clear();
    }

#line 155 "src/io/Buffer.birch"
void Buffer_::setEmptyObject(const String& key) {
  auto value = make_buffer();
  #line 157 "src/io/Buffer.birch"
  value->setEmptyObject();
  #line 158 "src/io/Buffer.birch"
  set(key, value);
}

#line 164 "src/io/Buffer.birch"
void Buffer_::setEmptyArray() {
  #line 165 "src/io/Buffer.birch"
  setNil();
  #line 166 "src/io/Buffer.birch"
  values = construct<Array<Buffer>>();
  #line 167 "src/io/Buffer.birch"

    map.clear();
    }

#line 175 "src/io/Buffer.birch"
void Buffer_::setEmptyArray(const String& key) {
  auto value = make_buffer();
  #line 177 "src/io/Buffer.birch"
  value->setEmptyArray();
  #line 178 "src/io/Buffer.birch"
  set(key, value);
}

#line 185 "src/io/Buffer.birch"
void Buffer_::split() {
  auto iter = walk();
  #line 187 "src/io/Buffer.birch"
  setNil();
  #line 188 "src/io/Buffer.birch"
  while (iter->hasNext()) {
    #line 189 "src/io/Buffer.birch"
    push(iter->next());
  }
  #line 191 "src/io/Buffer.birch"
  assert(isEmpty() || (!((bool(keys))) && (bool(values))));
}

#line 201 "src/io/Buffer.birch"
Integer Buffer_::size() {
  #line 202 "src/io/Buffer.birch"
  if ((bool(keys)) || (bool(scalarString)) || (bool(scalarReal)) || (bool(scalarInteger)) || (bool(scalarBoolean))) {
    #line 204 "src/io/Buffer.birch"
    return 1;
  } else {
    #line 205 "src/io/Buffer.birch"
    if ((bool(values))) {
      #line 206 "src/io/Buffer.birch"
      return (*(values))->size();
    } else {
      #line 207 "src/io/Buffer.birch"
      if ((bool(vectorReal))) {
        #line 208 "src/io/Buffer.birch"
        return length((*(vectorReal)));
      } else {
        #line 209 "src/io/Buffer.birch"
        if ((bool(vectorInteger))) {
          #line 210 "src/io/Buffer.birch"
          return length((*(vectorInteger)));
        } else {
          #line 211 "src/io/Buffer.birch"
          if ((bool(vectorBoolean))) {
            #line 212 "src/io/Buffer.birch"
            return length((*(vectorBoolean)));
          } else {
            #line 213 "src/io/Buffer.birch"
            if ((bool(matrixReal))) {
              #line 214 "src/io/Buffer.birch"
              return rows((*(matrixReal)));
            } else {
              #line 215 "src/io/Buffer.birch"
              if ((bool(matrixInteger))) {
                #line 216 "src/io/Buffer.birch"
                return rows((*(matrixInteger)));
              } else {
                #line 217 "src/io/Buffer.birch"
                if ((bool(matrixBoolean))) {
                  #line 218 "src/io/Buffer.birch"
                  return rows((*(matrixBoolean)));
                } else {
                  #line 220 "src/io/Buffer.birch"
                  return 0;
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 231 "src/io/Buffer.birch"
Integer Buffer_::size(const String& key) {
  auto buffer = get(key);
  #line 233 "src/io/Buffer.birch"
  if ((bool(buffer))) {
    #line 234 "src/io/Buffer.birch"
    return (*(buffer))->size();
  } else {
    #line 236 "src/io/Buffer.birch"
    return 0;
  }
}

#line 384 "src/io/Buffer.birch"
std::optional<Buffer> Buffer_::get(const String& key) {
  #line 385 "src/io/Buffer.birch"

    auto iter = map.find(key);
    if (iter != map.end()) {
      return values.value()(iter->second);
    }
      #line 391 "src/io/Buffer.birch"
  return std::nullopt;
}

#line 400 "src/io/Buffer.birch"
void Buffer_::set(const Array<String>& keys, const Array<Buffer>& values) {
  #line 401 "src/io/Buffer.birch"
  assert(keys->size() == values->size());
  #line 402 "src/io/Buffer.birch"
  setNil();
  #line 403 "src/io/Buffer.birch"
  this->keys = keys;
  #line 404 "src/io/Buffer.birch"
  this->values = values;
  #line 405 "src/io/Buffer.birch"

    map.clear();
      auto len = keys->size();
  #line 409 "src/io/Buffer.birch"
  for (int i = int(1); i <= int(len); ++i) {
    #line 410 "src/io/Buffer.birch"

      map.insert(std::make_pair(keys(i), i));
        }
}

#line 445 "src/io/Buffer.birch"
void Buffer_::set(const String& key, const Array<String>& keys, const Array<Buffer>& values) {
  #line 446 "src/io/Buffer.birch"
  set(key, make_buffer(keys, values));
}

#line 485 "src/io/Buffer.birch"
void Buffer_::set(const String& key, const Buffer& x) {
  #line 486 "src/io/Buffer.birch"
  if (!((bool(keys)))) {
    #line 487 "src/io/Buffer.birch"
    setEmptyObject();
  }
  #line 489 "src/io/Buffer.birch"
  (*(keys))->pushBack(key);
  #line 490 "src/io/Buffer.birch"
  (*(values))->pushBack(x);
  #line 491 "src/io/Buffer.birch"

    map.insert(std::make_pair(key, values.value()->size()));
    }

#line 503 "src/io/Buffer.birch"
Iterator<Buffer> Buffer_::walk() {
  #line 504 "src/io/Buffer.birch"
  if ((bool(keys))) {
    #line 505 "src/io/Buffer.birch"
    return construct<ObjectBufferIterator>((*(keys)), (*(values)));
  } else {
    #line 506 "src/io/Buffer.birch"
    if ((bool(values))) {
      #line 507 "src/io/Buffer.birch"
      return construct<ArrayBufferIterator>((*(values)));
    } else {
      #line 508 "src/io/Buffer.birch"
      if ((bool(scalarString))) {
        #line 509 "src/io/Buffer.birch"
        return construct<ScalarBufferIterator<String>>((*(scalarString)));
      } else {
        #line 510 "src/io/Buffer.birch"
        if ((bool(scalarReal))) {
          #line 511 "src/io/Buffer.birch"
          return construct<ScalarBufferIterator<Real>>((*(scalarReal)));
        } else {
          #line 512 "src/io/Buffer.birch"
          if ((bool(scalarInteger))) {
            #line 513 "src/io/Buffer.birch"
            return construct<ScalarBufferIterator<Integer>>((*(scalarInteger)));
          } else {
            #line 514 "src/io/Buffer.birch"
            if ((bool(scalarBoolean))) {
              #line 515 "src/io/Buffer.birch"
              return construct<ScalarBufferIterator<Boolean>>((*(scalarBoolean)));
            } else {
              #line 516 "src/io/Buffer.birch"
              if ((bool(vectorReal))) {
                #line 517 "src/io/Buffer.birch"
                return construct<VectorBufferIterator<Real>>((*(vectorReal)));
              } else {
                #line 518 "src/io/Buffer.birch"
                if ((bool(vectorInteger))) {
                  #line 519 "src/io/Buffer.birch"
                  return construct<VectorBufferIterator<Integer>>((*(vectorInteger)));
                } else {
                  #line 520 "src/io/Buffer.birch"
                  if ((bool(vectorBoolean))) {
                    #line 521 "src/io/Buffer.birch"
                    return construct<VectorBufferIterator<Boolean>>((*(vectorBoolean)));
                  } else {
                    #line 522 "src/io/Buffer.birch"
                    if ((bool(matrixReal))) {
                      #line 523 "src/io/Buffer.birch"
                      return construct<MatrixBufferIterator<Real>>((*(matrixReal)));
                    } else {
                      #line 524 "src/io/Buffer.birch"
                      if ((bool(matrixInteger))) {
                        #line 525 "src/io/Buffer.birch"
                        return construct<MatrixBufferIterator<Integer>>((*(matrixInteger)));
                      } else {
                        #line 526 "src/io/Buffer.birch"
                        if ((bool(matrixBoolean))) {
                          #line 527 "src/io/Buffer.birch"
                          return construct<MatrixBufferIterator<Boolean>>((*(matrixBoolean)));
                        } else {
                          #line 529 "src/io/Buffer.birch"
                          return EmptyIterator<Buffer>();
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 541 "src/io/Buffer.birch"
Iterator<Buffer> Buffer_::walk(const String& key) {
  auto buffer = get(key);
  #line 543 "src/io/Buffer.birch"
  if ((bool(buffer))) {
    #line 544 "src/io/Buffer.birch"
    return (*(buffer))->walk();
  } else {
    #line 546 "src/io/Buffer.birch"
    return EmptyIterator<Buffer>();
  }
}

#line 579 "src/io/Buffer.birch"
void Buffer_::push(const Buffer& x) {
  #line 580 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 581 "src/io/Buffer.birch"
    setEmptyArray();
    #line 582 "src/io/Buffer.birch"
    (*(values))->pushBack(x);
  } else {
    #line 583 "src/io/Buffer.birch"
    if (!((bool(keys))) && (bool(values))) {
      #line 584 "src/io/Buffer.birch"
      (*(values))->pushBack(x);
    } else {
      #line 586 "src/io/Buffer.birch"
      split();
      #line 587 "src/io/Buffer.birch"
      push(x);
    }
  }
}

#line 631 "src/io/Buffer.birch"
void Buffer_::push(const String& key, const Buffer& x) {
  auto buffer = get(key);
  #line 633 "src/io/Buffer.birch"
  if (!((bool(buffer)))) {
    #line 634 "src/io/Buffer.birch"
    buffer = make_buffer();
    #line 635 "src/io/Buffer.birch"
    set(key, (*(buffer)));
  }
  #line 637 "src/io/Buffer.birch"
  (*(buffer))->push(x);
}

#line 643 "src/io/Buffer.birch"
void Buffer_::pushNil() {
  #line 644 "src/io/Buffer.birch"
  push(make_buffer());
}

#line 652 "src/io/Buffer.birch"
void Buffer_::pushNil(const String& key) {
  #line 653 "src/io/Buffer.birch"
  push(key, make_buffer());
}

#line 656 "src/io/Buffer.birch"
void Buffer_::accept(const Writer& writer) {
  #line 657 "src/io/Buffer.birch"
  if ((bool(keys))) {
    #line 658 "src/io/Buffer.birch"
    writer->visit((*(keys)), (*(values)));
  } else {
    #line 659 "src/io/Buffer.birch"
    if ((bool(values))) {
      #line 660 "src/io/Buffer.birch"
      writer->visit((*(values)));
    } else {
      #line 661 "src/io/Buffer.birch"
      if ((bool(scalarString))) {
        #line 662 "src/io/Buffer.birch"
        writer->visit((*(scalarString)));
      } else {
        #line 663 "src/io/Buffer.birch"
        if ((bool(scalarReal))) {
          #line 664 "src/io/Buffer.birch"
          writer->visit((*(scalarReal)));
        } else {
          #line 665 "src/io/Buffer.birch"
          if ((bool(scalarInteger))) {
            #line 666 "src/io/Buffer.birch"
            writer->visit((*(scalarInteger)));
          } else {
            #line 667 "src/io/Buffer.birch"
            if ((bool(scalarBoolean))) {
              #line 668 "src/io/Buffer.birch"
              writer->visit((*(scalarBoolean)));
            } else {
              #line 669 "src/io/Buffer.birch"
              if ((bool(vectorReal))) {
                #line 670 "src/io/Buffer.birch"
                writer->visit((*(vectorReal)));
              } else {
                #line 671 "src/io/Buffer.birch"
                if ((bool(vectorInteger))) {
                  #line 672 "src/io/Buffer.birch"
                  writer->visit((*(vectorInteger)));
                } else {
                  #line 673 "src/io/Buffer.birch"
                  if ((bool(vectorBoolean))) {
                    #line 674 "src/io/Buffer.birch"
                    writer->visit((*(vectorBoolean)));
                  } else {
                    #line 675 "src/io/Buffer.birch"
                    if ((bool(matrixReal))) {
                      #line 676 "src/io/Buffer.birch"
                      writer->visit((*(matrixReal)));
                    } else {
                      #line 677 "src/io/Buffer.birch"
                      if ((bool(matrixInteger))) {
                        #line 678 "src/io/Buffer.birch"
                        writer->visit((*(matrixInteger)));
                      } else {
                        #line 679 "src/io/Buffer.birch"
                        if ((bool(matrixBoolean))) {
                          #line 680 "src/io/Buffer.birch"
                          writer->visit((*(matrixBoolean)));
                        } else {
                          #line 682 "src/io/Buffer.birch"
                          writer->visitNil();
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

#line 686 "src/io/Buffer.birch"
std::optional<Boolean> Buffer_::doGet(const std::optional<Boolean>& x) {
  #line 687 "src/io/Buffer.birch"
  if ((bool(scalarBoolean))) {
    #line 688 "src/io/Buffer.birch"
    return (*(scalarBoolean));
  } else {
    #line 689 "src/io/Buffer.birch"
    if ((bool(scalarInteger))) {
      #line 690 "src/io/Buffer.birch"
      return cast<Boolean>((*(scalarInteger)));
    } else {
      #line 691 "src/io/Buffer.birch"
      if ((bool(scalarReal))) {
        #line 692 "src/io/Buffer.birch"
        return cast<Boolean>((*(scalarReal)));
      } else {
        #line 693 "src/io/Buffer.birch"
        if ((bool(scalarString))) {
          #line 694 "src/io/Buffer.birch"
          return from_string<Boolean>((*(scalarString)));
        } else {
          #line 696 "src/io/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 700 "src/io/Buffer.birch"
std::optional<Integer> Buffer_::doGet(const std::optional<Integer>& x) {
  #line 701 "src/io/Buffer.birch"
  if ((bool(scalarBoolean))) {
    #line 702 "src/io/Buffer.birch"
    return cast<Integer>((*(scalarBoolean)));
  } else {
    #line 703 "src/io/Buffer.birch"
    if ((bool(scalarInteger))) {
      #line 704 "src/io/Buffer.birch"
      return (*(scalarInteger));
    } else {
      #line 705 "src/io/Buffer.birch"
      if ((bool(scalarReal))) {
        #line 706 "src/io/Buffer.birch"
        return cast<Integer>((*(scalarReal)));
      } else {
        #line 707 "src/io/Buffer.birch"
        if ((bool(scalarString))) {
          #line 708 "src/io/Buffer.birch"
          return from_string<Integer>((*(scalarString)));
        } else {
          #line 710 "src/io/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 714 "src/io/Buffer.birch"
std::optional<Real> Buffer_::doGet(const std::optional<Real>& x) {
  #line 715 "src/io/Buffer.birch"
  if ((bool(scalarBoolean))) {
    #line 716 "src/io/Buffer.birch"
    return cast<Real>((*(scalarBoolean)));
  } else {
    #line 717 "src/io/Buffer.birch"
    if ((bool(scalarInteger))) {
      #line 718 "src/io/Buffer.birch"
      return cast<Real>((*(scalarInteger)));
    } else {
      #line 719 "src/io/Buffer.birch"
      if ((bool(scalarReal))) {
        #line 720 "src/io/Buffer.birch"
        return (*(scalarReal));
      } else {
        #line 721 "src/io/Buffer.birch"
        if ((bool(scalarString))) {
          #line 722 "src/io/Buffer.birch"
          return from_string<Real>((*(scalarString)));
        } else {
          #line 724 "src/io/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 728 "src/io/Buffer.birch"
std::optional<String> Buffer_::doGet(const std::optional<String>& x) {
  #line 729 "src/io/Buffer.birch"
  if ((bool(scalarBoolean))) {
    #line 730 "src/io/Buffer.birch"
    return to_string((*(scalarBoolean)));
  } else {
    #line 731 "src/io/Buffer.birch"
    if ((bool(scalarInteger))) {
      #line 732 "src/io/Buffer.birch"
      return to_string((*(scalarInteger)));
    } else {
      #line 733 "src/io/Buffer.birch"
      if ((bool(scalarReal))) {
        #line 734 "src/io/Buffer.birch"
        return to_string((*(scalarReal)));
      } else {
        #line 735 "src/io/Buffer.birch"
        if ((bool(scalarString))) {
          #line 736 "src/io/Buffer.birch"
          return (*(scalarString));
        } else {
          #line 738 "src/io/Buffer.birch"
          return std::nullopt;
        }
      }
    }
  }
}

#line 746 "src/io/Buffer.birch"
std::optional<numbirch::Array<Boolean,1>> Buffer_::doGet(const std::optional<numbirch::Array<Boolean,1>>& x) {
  #line 747 "src/io/Buffer.birch"
  if ((bool(vectorBoolean))) {
    #line 748 "src/io/Buffer.birch"
    return (*(vectorBoolean));
  } else {
    #line 749 "src/io/Buffer.birch"
    if ((bool(vectorInteger))) {
      #line 750 "src/io/Buffer.birch"
      return cast<Boolean>((*(vectorInteger)));
    } else {
      #line 751 "src/io/Buffer.birch"
      if ((bool(vectorReal))) {
        #line 752 "src/io/Buffer.birch"
        return cast<Boolean>((*(vectorReal)));
      } else {
        #line 754 "src/io/Buffer.birch"
        return doGetVector<Boolean>();
      }
    }
  }
}

#line 758 "src/io/Buffer.birch"
std::optional<numbirch::Array<Integer,1>> Buffer_::doGet(const std::optional<numbirch::Array<Integer,1>>& x) {
  #line 759 "src/io/Buffer.birch"
  if ((bool(vectorBoolean))) {
    #line 760 "src/io/Buffer.birch"
    return cast<Integer>((*(vectorBoolean)));
  } else {
    #line 761 "src/io/Buffer.birch"
    if ((bool(vectorInteger))) {
      #line 762 "src/io/Buffer.birch"
      return (*(vectorInteger));
    } else {
      #line 763 "src/io/Buffer.birch"
      if ((bool(vectorReal))) {
        #line 764 "src/io/Buffer.birch"
        return cast<Integer>((*(vectorReal)));
      } else {
        #line 766 "src/io/Buffer.birch"
        return doGetVector<Integer>();
      }
    }
  }
}

#line 770 "src/io/Buffer.birch"
std::optional<numbirch::Array<Real,1>> Buffer_::doGet(const std::optional<numbirch::Array<Real,1>>& x) {
  #line 771 "src/io/Buffer.birch"
  if ((bool(vectorBoolean))) {
    #line 772 "src/io/Buffer.birch"
    return cast<Real>((*(vectorBoolean)));
  } else {
    #line 773 "src/io/Buffer.birch"
    if ((bool(vectorInteger))) {
      #line 774 "src/io/Buffer.birch"
      return cast<Real>((*(vectorInteger)));
    } else {
      #line 775 "src/io/Buffer.birch"
      if ((bool(vectorReal))) {
        #line 776 "src/io/Buffer.birch"
        return (*(vectorReal));
      } else {
        #line 778 "src/io/Buffer.birch"
        return doGetVector<Real>();
      }
    }
  }
}

#line 806 "src/io/Buffer.birch"
std::optional<numbirch::Array<Boolean,2>> Buffer_::doGet(const std::optional<numbirch::Array<Boolean,2>>& x) {
  #line 807 "src/io/Buffer.birch"
  if ((bool(matrixBoolean))) {
    #line 808 "src/io/Buffer.birch"
    return (*(matrixBoolean));
  } else {
    #line 809 "src/io/Buffer.birch"
    if ((bool(matrixInteger))) {
      #line 810 "src/io/Buffer.birch"
      return cast<Boolean>((*(matrixInteger)));
    } else {
      #line 811 "src/io/Buffer.birch"
      if ((bool(matrixReal))) {
        #line 812 "src/io/Buffer.birch"
        return cast<Boolean>((*(matrixReal)));
      } else {
        #line 814 "src/io/Buffer.birch"
        return doGetMatrix<Boolean>();
      }
    }
  }
}

#line 818 "src/io/Buffer.birch"
std::optional<numbirch::Array<Integer,2>> Buffer_::doGet(const std::optional<numbirch::Array<Integer,2>>& x) {
  #line 819 "src/io/Buffer.birch"
  if ((bool(matrixBoolean))) {
    #line 820 "src/io/Buffer.birch"
    return cast<Integer>((*(matrixBoolean)));
  } else {
    #line 821 "src/io/Buffer.birch"
    if ((bool(matrixInteger))) {
      #line 822 "src/io/Buffer.birch"
      return (*(matrixInteger));
    } else {
      #line 823 "src/io/Buffer.birch"
      if ((bool(matrixReal))) {
        #line 824 "src/io/Buffer.birch"
        return cast<Integer>((*(matrixReal)));
      } else {
        #line 826 "src/io/Buffer.birch"
        return doGetMatrix<Integer>();
      }
    }
  }
}

#line 830 "src/io/Buffer.birch"
std::optional<numbirch::Array<Real,2>> Buffer_::doGet(const std::optional<numbirch::Array<Real,2>>& x) {
  #line 831 "src/io/Buffer.birch"
  if ((bool(matrixBoolean))) {
    #line 832 "src/io/Buffer.birch"
    return cast<Real>((*(matrixBoolean)));
  } else {
    #line 833 "src/io/Buffer.birch"
    if ((bool(matrixInteger))) {
      #line 834 "src/io/Buffer.birch"
      return cast<Real>((*(matrixInteger)));
    } else {
      #line 835 "src/io/Buffer.birch"
      if ((bool(matrixReal))) {
        #line 836 "src/io/Buffer.birch"
        return (*(matrixReal));
      } else {
        #line 838 "src/io/Buffer.birch"
        return doGetMatrix<Real>();
      }
    }
  }
}

#line 875 "src/io/Buffer.birch"
std::optional<Boolean> Buffer_::doGet(const Integer& t, const std::optional<Boolean>& x) {
  #line 876 "src/io/Buffer.birch"
  return doGet(x);
}

#line 879 "src/io/Buffer.birch"
std::optional<Integer> Buffer_::doGet(const Integer& t, const std::optional<Integer>& x) {
  #line 880 "src/io/Buffer.birch"
  return doGet(x);
}

#line 883 "src/io/Buffer.birch"
std::optional<Real> Buffer_::doGet(const Integer& t, const std::optional<Real>& x) {
  #line 884 "src/io/Buffer.birch"
  return doGet(x);
}

#line 887 "src/io/Buffer.birch"
std::optional<String> Buffer_::doGet(const Integer& t, const std::optional<String>& x) {
  #line 888 "src/io/Buffer.birch"
  return doGet(x);
}

#line 895 "src/io/Buffer.birch"
std::optional<numbirch::Array<Boolean,1>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Boolean,1>>& x) {
  #line 896 "src/io/Buffer.birch"
  return doGet(x);
}

#line 899 "src/io/Buffer.birch"
std::optional<numbirch::Array<Integer,1>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Integer,1>>& x) {
  #line 900 "src/io/Buffer.birch"
  return doGet(x);
}

#line 903 "src/io/Buffer.birch"
std::optional<numbirch::Array<Real,1>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Real,1>>& x) {
  #line 904 "src/io/Buffer.birch"
  return doGet(x);
}

#line 915 "src/io/Buffer.birch"
std::optional<numbirch::Array<Boolean,2>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Boolean,2>>& x) {
  #line 916 "src/io/Buffer.birch"
  return doGet(x);
}

#line 919 "src/io/Buffer.birch"
std::optional<numbirch::Array<Integer,2>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Integer,2>>& x) {
  #line 920 "src/io/Buffer.birch"
  return doGet(x);
}

#line 923 "src/io/Buffer.birch"
std::optional<numbirch::Array<Real,2>> Buffer_::doGet(const Integer& t, const std::optional<numbirch::Array<Real,2>>& x) {
  #line 924 "src/io/Buffer.birch"
  return doGet(x);
}

#line 935 "src/io/Buffer.birch"
void Buffer_::doSet(const Boolean& x) {
  #line 936 "src/io/Buffer.birch"
  setNil();
  #line 937 "src/io/Buffer.birch"
  scalarBoolean = x;
}

#line 940 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Future<Boolean>& x) {
  #line 941 "src/io/Buffer.birch"
  doSet((*(x)));
}

#line 944 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& x) {
  #line 945 "src/io/Buffer.birch"
  setNil();
  #line 946 "src/io/Buffer.birch"
  scalarInteger = x;
}

#line 949 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Future<Integer>& x) {
  #line 950 "src/io/Buffer.birch"
  doSet((*(x)));
}

#line 953 "src/io/Buffer.birch"
void Buffer_::doSet(const Real& x) {
  #line 954 "src/io/Buffer.birch"
  setNil();
  #line 955 "src/io/Buffer.birch"
  scalarReal = x;
}

#line 958 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Future<Real>& x) {
  #line 959 "src/io/Buffer.birch"
  doSet((*(x)));
}

#line 962 "src/io/Buffer.birch"
void Buffer_::doSet(const String& x) {
  #line 963 "src/io/Buffer.birch"
  setNil();
  #line 964 "src/io/Buffer.birch"
  scalarString = x;
}

#line 967 "src/io/Buffer.birch"
void Buffer_::doSet(const Object& x) {
  #line 968 "src/io/Buffer.birch"
  setNil();
  #line 969 "src/io/Buffer.birch"
  x->write(membirch::Shared<this_type_>(this));
}

#line 972 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Boolean,1>& x) {
  #line 973 "src/io/Buffer.birch"
  setNil();
  #line 974 "src/io/Buffer.birch"
  vectorBoolean = x;
}

#line 977 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Integer,1>& x) {
  #line 978 "src/io/Buffer.birch"
  setNil();
  #line 979 "src/io/Buffer.birch"
  vectorInteger = x;
}

#line 982 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Real,1>& x) {
  #line 983 "src/io/Buffer.birch"
  setNil();
  #line 984 "src/io/Buffer.birch"
  vectorReal = x;
}

#line 987 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Boolean,2>& x) {
  #line 988 "src/io/Buffer.birch"
  setNil();
  #line 989 "src/io/Buffer.birch"
  matrixBoolean = x;
}

#line 992 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Integer,2>& x) {
  #line 993 "src/io/Buffer.birch"
  setNil();
  #line 994 "src/io/Buffer.birch"
  matrixInteger = x;
}

#line 997 "src/io/Buffer.birch"
void Buffer_::doSet(const numbirch::Array<Real,2>& x) {
  #line 998 "src/io/Buffer.birch"
  setNil();
  #line 999 "src/io/Buffer.birch"
  matrixReal = x;
}

#line 1002 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const Boolean& x) {
  #line 1003 "src/io/Buffer.birch"
  doSet(x);
}

#line 1006 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Future<Boolean>& x) {
  #line 1007 "src/io/Buffer.birch"
  doSet(x);
}

#line 1010 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const Integer& x) {
  #line 1011 "src/io/Buffer.birch"
  doSet(x);
}

#line 1014 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Future<Integer>& x) {
  #line 1015 "src/io/Buffer.birch"
  doSet(x);
}

#line 1018 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const Real& x) {
  #line 1019 "src/io/Buffer.birch"
  doSet(x);
}

#line 1022 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Future<Real>& x) {
  #line 1023 "src/io/Buffer.birch"
  doSet(x);
}

#line 1026 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const String& x) {
  #line 1027 "src/io/Buffer.birch"
  doSet(x);
}

#line 1030 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const Object& x) {
  #line 1031 "src/io/Buffer.birch"
  setNil();
  #line 1032 "src/io/Buffer.birch"
  x->write(t, membirch::Shared<this_type_>(this));
}

#line 1035 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Boolean,1>& x) {
  #line 1036 "src/io/Buffer.birch"
  doSet(x);
}

#line 1039 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Integer,1>& x) {
  #line 1040 "src/io/Buffer.birch"
  doSet(x);
}

#line 1043 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Real,1>& x) {
  #line 1044 "src/io/Buffer.birch"
  doSet(x);
}

#line 1047 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Boolean,2>& x) {
  #line 1048 "src/io/Buffer.birch"
  doSet(x);
}

#line 1051 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Integer,2>& x) {
  #line 1052 "src/io/Buffer.birch"
  doSet(x);
}

#line 1055 "src/io/Buffer.birch"
void Buffer_::doSet(const Integer& t, const numbirch::Array<Real,2>& x) {
  #line 1056 "src/io/Buffer.birch"
  doSet(x);
}

#line 1059 "src/io/Buffer.birch"
void Buffer_::doPush(const Boolean& x) {
  #line 1060 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1061 "src/io/Buffer.birch"
    set(x);
  } else {
    #line 1062 "src/io/Buffer.birch"
    if ((bool(scalarBoolean))) {
      #line 1063 "src/io/Buffer.birch"
      set(stack((*(scalarBoolean)), x));
    } else {
      #line 1064 "src/io/Buffer.birch"
      if ((bool(scalarInteger))) {
        #line 1065 "src/io/Buffer.birch"
        set(stack((*(scalarInteger)), cast<Integer>(x)));
      } else {
        #line 1066 "src/io/Buffer.birch"
        if ((bool(scalarReal))) {
          #line 1067 "src/io/Buffer.birch"
          set(stack((*(scalarReal)), cast<Real>(x)));
        } else {
          #line 1068 "src/io/Buffer.birch"
          if ((bool(vectorBoolean))) {
            #line 1069 "src/io/Buffer.birch"

      vectorBoolean.value().push(x);
                } else {
            #line 1072 "src/io/Buffer.birch"
            if ((bool(vectorInteger))) {
              #line 1073 "src/io/Buffer.birch"
              push(cast<Integer>(x));
            } else {
              #line 1074 "src/io/Buffer.birch"
              if ((bool(vectorReal))) {
                #line 1075 "src/io/Buffer.birch"
                push(cast<Real>(x));
              } else {
                #line 1077 "src/io/Buffer.birch"
                push(make_buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 1081 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Future<Boolean>& x) {
  #line 1082 "src/io/Buffer.birch"
  doPush((*(x)));
}

#line 1085 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& x) {
  #line 1086 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1087 "src/io/Buffer.birch"
    set(x);
  } else {
    #line 1088 "src/io/Buffer.birch"
    if ((bool(scalarBoolean))) {
      #line 1089 "src/io/Buffer.birch"
      set(stack(cast<Integer>((*(scalarBoolean))), x));
    } else {
      #line 1090 "src/io/Buffer.birch"
      if ((bool(scalarInteger))) {
        #line 1091 "src/io/Buffer.birch"
        set(stack((*(scalarInteger)), x));
      } else {
        #line 1092 "src/io/Buffer.birch"
        if ((bool(scalarReal))) {
          #line 1093 "src/io/Buffer.birch"
          set(stack((*(scalarReal)), cast<Real>(x)));
        } else {
          #line 1094 "src/io/Buffer.birch"
          if ((bool(vectorBoolean))) {
            #line 1095 "src/io/Buffer.birch"
            set(stack(cast<Integer>((*(vectorBoolean))), x));
          } else {
            #line 1096 "src/io/Buffer.birch"
            if ((bool(vectorInteger))) {
              #line 1097 "src/io/Buffer.birch"

      vectorInteger.value().push(x);
                  } else {
              #line 1100 "src/io/Buffer.birch"
              if ((bool(vectorReal))) {
                #line 1101 "src/io/Buffer.birch"
                push(cast<Real>(x));
              } else {
                #line 1103 "src/io/Buffer.birch"
                push(make_buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 1107 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Future<Integer>& x) {
  #line 1108 "src/io/Buffer.birch"
  doPush((*(x)));
}

#line 1111 "src/io/Buffer.birch"
void Buffer_::doPush(const Real& x) {
  #line 1112 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1113 "src/io/Buffer.birch"
    set(x);
  } else {
    #line 1114 "src/io/Buffer.birch"
    if ((bool(scalarBoolean))) {
      #line 1115 "src/io/Buffer.birch"
      set(stack(cast<Real>((*(scalarBoolean))), x));
    } else {
      #line 1116 "src/io/Buffer.birch"
      if ((bool(scalarInteger))) {
        #line 1117 "src/io/Buffer.birch"
        set(stack(cast<Real>((*(scalarInteger))), x));
      } else {
        #line 1118 "src/io/Buffer.birch"
        if ((bool(scalarReal))) {
          #line 1119 "src/io/Buffer.birch"
          set(stack((*(scalarReal)), x));
        } else {
          #line 1120 "src/io/Buffer.birch"
          if ((bool(vectorBoolean))) {
            #line 1121 "src/io/Buffer.birch"
            set(stack(cast<Real>((*(vectorBoolean))), x));
          } else {
            #line 1122 "src/io/Buffer.birch"
            if ((bool(vectorInteger))) {
              #line 1123 "src/io/Buffer.birch"
              set(stack(cast<Real>((*(vectorInteger))), x));
            } else {
              #line 1124 "src/io/Buffer.birch"
              if ((bool(vectorReal))) {
                #line 1125 "src/io/Buffer.birch"

      vectorReal.value().push(x);
                    } else {
                #line 1129 "src/io/Buffer.birch"
                push(make_buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 1133 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Future<Real>& x) {
  #line 1134 "src/io/Buffer.birch"
  doPush((*(x)));
}

#line 1137 "src/io/Buffer.birch"
void Buffer_::doPush(const String& x) {
  #line 1138 "src/io/Buffer.birch"
  push(make_buffer(x));
}

#line 1141 "src/io/Buffer.birch"
void Buffer_::doPush(const Object& x) {
  #line 1142 "src/io/Buffer.birch"
  push(make_buffer(x));
}

#line 1145 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Boolean,1>& x) {
  #line 1146 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1147 "src/io/Buffer.birch"
    set(row(x));
  } else {
    #line 1148 "src/io/Buffer.birch"
    if ((bool(vectorBoolean))) {
      #line 1149 "src/io/Buffer.birch"
      set(stack(row((*(vectorBoolean))), row(x)));
    } else {
      #line 1150 "src/io/Buffer.birch"
      if ((bool(matrixBoolean)) && columns((*(matrixBoolean))) == length(x)) {
        #line 1151 "src/io/Buffer.birch"
        set(stack((*(matrixBoolean)), row(x)));
      } else {
        #line 1152 "src/io/Buffer.birch"
        if ((bool(vectorInteger)) || (bool(matrixInteger))) {
          #line 1153 "src/io/Buffer.birch"
          push(cast<Integer>(x));
        } else {
          #line 1154 "src/io/Buffer.birch"
          if ((bool(vectorReal)) || (bool(matrixReal))) {
            #line 1155 "src/io/Buffer.birch"
            push(cast<Real>(x));
          } else {
            #line 1157 "src/io/Buffer.birch"
            push(make_buffer(x));
          }
        }
      }
    }
  }
}

#line 1161 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Integer,1>& x) {
  #line 1162 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1163 "src/io/Buffer.birch"
    set(row(x));
  } else {
    #line 1164 "src/io/Buffer.birch"
    if ((bool(vectorBoolean))) {
      #line 1165 "src/io/Buffer.birch"
      set(stack(cast<Integer>(row((*(vectorBoolean)))), row(x)));
    } else {
      #line 1166 "src/io/Buffer.birch"
      if ((bool(matrixBoolean)) && columns((*(matrixBoolean))) == length(x)) {
        #line 1167 "src/io/Buffer.birch"
        set(stack(cast<Integer>((*(matrixBoolean))), row(x)));
      } else {
        #line 1168 "src/io/Buffer.birch"
        if ((bool(vectorInteger))) {
          #line 1169 "src/io/Buffer.birch"
          set(stack(row((*(vectorInteger))), row(x)));
        } else {
          #line 1170 "src/io/Buffer.birch"
          if ((bool(matrixInteger)) && columns((*(matrixInteger))) == length(x)) {
            #line 1171 "src/io/Buffer.birch"
            set(stack((*(matrixInteger)), row(x)));
          } else {
            #line 1172 "src/io/Buffer.birch"
            if ((bool(vectorReal)) || (bool(matrixReal))) {
              #line 1173 "src/io/Buffer.birch"
              push(cast<Real>(x));
            } else {
              #line 1175 "src/io/Buffer.birch"
              push(make_buffer(x));
            }
          }
        }
      }
    }
  }
}

#line 1179 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Real,1>& x) {
  #line 1180 "src/io/Buffer.birch"
  if (isEmpty()) {
    #line 1181 "src/io/Buffer.birch"
    set(row(x));
  } else {
    #line 1182 "src/io/Buffer.birch"
    if ((bool(vectorBoolean))) {
      #line 1183 "src/io/Buffer.birch"
      set(stack(cast<Real>(row((*(vectorBoolean)))), row(x)));
    } else {
      #line 1184 "src/io/Buffer.birch"
      if ((bool(matrixBoolean)) && columns((*(matrixBoolean))) == length(x)) {
        #line 1185 "src/io/Buffer.birch"
        set(stack(cast<Real>((*(matrixBoolean))), row(x)));
      } else {
        #line 1186 "src/io/Buffer.birch"
        if ((bool(vectorInteger))) {
          #line 1187 "src/io/Buffer.birch"
          set(stack(cast<Real>(row((*(vectorInteger)))), row(x)));
        } else {
          #line 1188 "src/io/Buffer.birch"
          if ((bool(matrixInteger)) && columns((*(matrixInteger))) == length(x)) {
            #line 1189 "src/io/Buffer.birch"
            set(stack(cast<Real>((*(matrixInteger))), row(x)));
          } else {
            #line 1190 "src/io/Buffer.birch"
            if ((bool(vectorReal))) {
              #line 1191 "src/io/Buffer.birch"
              set(stack(row((*(vectorReal))), row(x)));
            } else {
              #line 1192 "src/io/Buffer.birch"
              if ((bool(matrixReal)) && columns((*(matrixReal))) == length(x)) {
                #line 1193 "src/io/Buffer.birch"
                set(stack((*(matrixReal)), row(x)));
              } else {
                #line 1195 "src/io/Buffer.birch"
                push(make_buffer(x));
              }
            }
          }
        }
      }
    }
  }
}

#line 1199 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Boolean,2>& x) {
  #line 1200 "src/io/Buffer.birch"
  push(make_buffer(x));
}

#line 1203 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Integer,2>& x) {
  #line 1204 "src/io/Buffer.birch"
  push(make_buffer(x));
}

#line 1207 "src/io/Buffer.birch"
void Buffer_::doPush(const numbirch::Array<Real,2>& x) {
  #line 1208 "src/io/Buffer.birch"
  push(make_buffer(x));
}

#line 1211 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const Boolean& x) {
  #line 1212 "src/io/Buffer.birch"
  doPush(x);
}

#line 1215 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Future<Boolean>& x) {
  #line 1216 "src/io/Buffer.birch"
  doPush(x);
}

#line 1219 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const Integer& x) {
  #line 1220 "src/io/Buffer.birch"
  doPush(x);
}

#line 1223 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Future<Integer>& x) {
  #line 1224 "src/io/Buffer.birch"
  doPush(x);
}

#line 1227 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const Real& x) {
  #line 1228 "src/io/Buffer.birch"
  doPush(x);
}

#line 1231 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Future<Real>& x) {
  #line 1232 "src/io/Buffer.birch"
  doPush(x);
}

#line 1235 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const String& x) {
  #line 1236 "src/io/Buffer.birch"
  doPush(x);
}

#line 1239 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const Object& x) {
  #line 1240 "src/io/Buffer.birch"
  push(make_buffer(t, x));
}

#line 1243 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Boolean,1>& x) {
  #line 1244 "src/io/Buffer.birch"
  doPush(x);
}

#line 1247 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Integer,1>& x) {
  #line 1248 "src/io/Buffer.birch"
  doPush(x);
}

#line 1251 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Real,1>& x) {
  #line 1252 "src/io/Buffer.birch"
  doPush(x);
}

#line 1255 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Boolean,2>& x) {
  #line 1256 "src/io/Buffer.birch"
  doPush(x);
}

#line 1259 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Integer,2>& x) {
  #line 1260 "src/io/Buffer.birch"
  doPush(x);
}

#line 1263 "src/io/Buffer.birch"
void Buffer_::doPush(const Integer& t, const numbirch::Array<Real,2>& x) {
  #line 1264 "src/io/Buffer.birch"
  doPush(x);
}

#line 24 "src/io/Buffer.birch"
Object_* make_Buffer_() {
  #line 24 "src/io/Buffer.birch"
  return new Buffer_();
  #line 24 "src/io/Buffer.birch"
}
static int register_factory_Buffer_ = ::register_factory("Buffer", make_Buffer_);


/**
 * Create a Buffer.
 */
#line 1271 "src/io/Buffer.birch"
Buffer make_buffer() {
  #line 1272 "src/io/Buffer.birch"
  return construct<Buffer>();
}


/**
 * Create a Buffer representing an object (in the JSON sense).
 *
 * @param keys Keys.
 * @param values Values.
 */
#line 1304 "src/io/Buffer.birch"
Buffer make_buffer(const Array<String>& keys, const Array<Buffer>& values) {
  Buffer o;
  #line 1306 "src/io/Buffer.birch"
  o->set(keys, values);
  #line 1307 "src/io/Buffer.birch"
  return o;
}

}
namespace birch {
#line 1 "src/io/InputStream.birch"
InputStream_::InputStream_() :
    #line 1 "src/io/InputStream.birch"
    base_type_(),
    #line 8 "src/io/InputStream.birch"
    file() {
  //
}

#line 16 "src/io/InputStream.birch"
void InputStream_::open(const String& path, const Integer& mode) {
  #line 17 "src/io/InputStream.birch"
  assert(!(((bool(file)))));
  #line 18 "src/io/InputStream.birch"
  file = fopen(path, mode);
}

#line 26 "src/io/InputStream.birch"
void InputStream_::open(const String& path) {
  #line 27 "src/io/InputStream.birch"
  open(path, READ);
}

#line 33 "src/io/InputStream.birch"
void InputStream_::close() {
  #line 34 "src/io/InputStream.birch"
  assert((bool(file)));
  #line 35 "src/io/InputStream.birch"

    fclose(file.value());
      #line 38 "src/io/InputStream.birch"
  file = std::nullopt;
}

#line 44 "src/io/InputStream.birch"
Boolean InputStream_::eof() {
  #line 45 "src/io/InputStream.birch"
  assert((bool(file)));
  #line 46 "src/io/InputStream.birch"

    return feof(file.value());
    }

#line 54 "src/io/InputStream.birch"
std::optional<Integer> InputStream_::scanInteger() {
  #line 55 "src/io/InputStream.birch"
  assert((bool(file)));
  std::optional<Integer> x;
  #line 57 "src/io/InputStream.birch"

    long long int y;  // ensure that fscanf gets the exact type it expects
    auto res = ::fscanf(this->file.value(), "%lld", &y);
    if (res == 1) {
      x = Integer(y);
    } 
      #line 64 "src/io/InputStream.birch"
  return x;
}

#line 70 "src/io/InputStream.birch"
std::optional<Real> InputStream_::scanReal() {
  #line 71 "src/io/InputStream.birch"
  assert((bool(file)));
  std::optional<Real> x;
  #line 73 "src/io/InputStream.birch"

    double y;  // ensure that fscanf gets the exact type it expects
    if (::fscanf(this->file.value(), "%lf", &y) == 1) {
      x = Real(y);
    } 
      #line 79 "src/io/InputStream.birch"
  return x;
}

#line 1 "src/io/InputStream.birch"
Object_* make_InputStream_() {
  #line 1 "src/io/InputStream.birch"
  return new InputStream_();
  #line 1 "src/io/InputStream.birch"
}
static int register_factory_InputStream_ = ::register_factory("InputStream", make_InputStream_);


/**
 * Create an input stream from an already-open file.
 */
#line 86 "src/io/InputStream.birch"
InputStream make_input_stream(const File& file) {
  InputStream o;
  #line 88 "src/io/InputStream.birch"
  o->file = file;
  #line 89 "src/io/InputStream.birch"
  return o;
}

}
namespace birch {
}
namespace birch {
#line 1 "src/io/JSONWriter.birch"
JSONWriter_::JSONWriter_() :
    #line 1 "src/io/JSONWriter.birch"
    base_type_() {
  //
}

#line 14 "src/io/JSONWriter.birch"
void JSONWriter_::visit(const String& value) {
  #line 15 "src/io/JSONWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_DOUBLE_QUOTED_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 23 "src/io/JSONWriter.birch"
void JSONWriter_::startMapping() {
  #line 24 "src/io/JSONWriter.birch"

    yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 31 "src/io/JSONWriter.birch"
void JSONWriter_::startSequence() {
  #line 32 "src/io/JSONWriter.birch"

    yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_FLOW_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 1 "src/io/JSONWriter.birch"
Object_* make_JSONWriter_() {
  #line 1 "src/io/JSONWriter.birch"
  return new JSONWriter_();
  #line 1 "src/io/JSONWriter.birch"
}
static int register_factory_JSONWriter_ = ::register_factory("JSONWriter", make_JSONWriter_);

}
namespace birch {
}
namespace birch {
#line 8 "src/io/ObjectBufferIterator.birch"
ObjectBufferIterator_::ObjectBufferIterator_(const Array<String>& keys, const Array<Buffer>& values) :
    #line 8 "src/io/ObjectBufferIterator.birch"
    base_type_(),
    #line 13 "src/io/ObjectBufferIterator.birch"
    keys(keys),
    #line 18 "src/io/ObjectBufferIterator.birch"
    values(values) {
  //
}

#line 23 "src/io/ObjectBufferIterator.birch"
Boolean ObjectBufferIterator_::hasNext() {
  #line 24 "src/io/ObjectBufferIterator.birch"
  return (bool(keys)) && (bool(values));
}

#line 30 "src/io/ObjectBufferIterator.birch"
Buffer ObjectBufferIterator_::next() {
  auto buffer = make_buffer((*(keys)), (*(values)));
  #line 32 "src/io/ObjectBufferIterator.birch"
  keys = std::nullopt;
  #line 33 "src/io/ObjectBufferIterator.birch"
  values = std::nullopt;
  #line 34 "src/io/ObjectBufferIterator.birch"
  return buffer;
}

}
namespace birch {
#line 1 "src/io/OutputStream.birch"
OutputStream_::OutputStream_() :
    #line 1 "src/io/OutputStream.birch"
    base_type_(),
    #line 8 "src/io/OutputStream.birch"
    file() {
  //
}

#line 16 "src/io/OutputStream.birch"
void OutputStream_::open(const String& path, const Integer& mode) {
  #line 17 "src/io/OutputStream.birch"
  file = fopen(path, mode);
}

#line 25 "src/io/OutputStream.birch"
void OutputStream_::open(const String& path) {
  #line 26 "src/io/OutputStream.birch"
  open(path, WRITE);
}

#line 32 "src/io/OutputStream.birch"
void OutputStream_::close() {
  #line 33 "src/io/OutputStream.birch"
  assert((bool(file)));
  #line 34 "src/io/OutputStream.birch"

    fclose(file.value());
      #line 37 "src/io/OutputStream.birch"
  file = std::nullopt;
}

#line 43 "src/io/OutputStream.birch"
void OutputStream_::flush() {
  #line 44 "src/io/OutputStream.birch"
  assert((bool(file)));
  #line 45 "src/io/OutputStream.birch"

    fflush(file.value());
    }

#line 53 "src/io/OutputStream.birch"
void OutputStream_::print(const String& value) {
  #line 54 "src/io/OutputStream.birch"
  assert((bool(file)));
  #line 55 "src/io/OutputStream.birch"

    ::fprintf(this->file.value(), "%s", value.c_str());
    }

#line 63 "src/io/OutputStream.birch"
void OutputStream_::print(const Boolean& value) {
  #line 64 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 70 "src/io/OutputStream.birch"
void OutputStream_::print(const Integer& value) {
  #line 71 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 77 "src/io/OutputStream.birch"
void OutputStream_::print(const Real& value) {
  #line 78 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 84 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Boolean,1>& value) {
  #line 85 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 91 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Integer,1>& value) {
  #line 92 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 98 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Real,1>& value) {
  #line 99 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 105 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Boolean,2>& value) {
  #line 106 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 112 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Integer,2>& value) {
  #line 113 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 119 "src/io/OutputStream.birch"
void OutputStream_::print(const numbirch::Array<Real,2>& value) {
  #line 120 "src/io/OutputStream.birch"
  print(to_string(value));
}

#line 1 "src/io/OutputStream.birch"
Object_* make_OutputStream_() {
  #line 1 "src/io/OutputStream.birch"
  return new OutputStream_();
  #line 1 "src/io/OutputStream.birch"
}
static int register_factory_OutputStream_ = ::register_factory("OutputStream", make_OutputStream_);


/**
 * Create an output stream for an already-open file.
 */
#line 127 "src/io/OutputStream.birch"
OutputStream make_output_stream(const File& file) {
  OutputStream o;
  #line 129 "src/io/OutputStream.birch"
  o->file = file;
  #line 130 "src/io/OutputStream.birch"
  return o;
}

}
namespace birch {
#line 38 "src/io/Reader.birch"
Reader_::Reader_() :
    #line 38 "src/io/Reader.birch"
    base_type_() {
  //
}


/**
 * Create a reader for a file.
 *
 * @param path Path of the file.
 *
 * @return the reader.
 *
 * The file extension of `path` is used to determine the precise type of the
 * returned object. Supported file extension are `.json`, `.yml`, and `.yaml`.
 */
#line 69 "src/io/Reader.birch"
Reader make_reader(const String& path) {
  auto ext = extension(path);
  std::optional<Reader> result;
  #line 72 "src/io/Reader.birch"
  if (ext == String(".json")) {
    JSONReader reader;
    #line 74 "src/io/Reader.birch"
    reader->open(path);
    #line 75 "src/io/Reader.birch"
    result = reader;
  } else {
    #line 76 "src/io/Reader.birch"
    if (ext == String(".yml") || ext == String(".yaml")) {
      YAMLReader reader;
      #line 78 "src/io/Reader.birch"
      reader->open(path);
      #line 79 "src/io/Reader.birch"
      result = reader;
    }
  }
  #line 81 "src/io/Reader.birch"
  if (!((bool(result)))) {
    #line 82 "src/io/Reader.birch"
    error(String("unrecognized file extension '") + ext + String("' in path '") + path + String("'; supported extensions are '.json', '.yml' and '.yaml'."));
  }
  #line 85 "src/io/Reader.birch"
  return (*(result));
}


/**
 * Read the whole contents of a file into a buffer.
 *
 * @param path Path of the file.
 *
 * @return the contents.
 */
#line 95 "src/io/Reader.birch"
Buffer slurp(const String& path) {
  auto reader = make_reader(path);
  auto buffer = reader->slurp();
  #line 98 "src/io/Reader.birch"
  reader->close();
  #line 99 "src/io/Reader.birch"
  return buffer;
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 37 "src/io/Writer.birch"
Writer_::Writer_() :
    #line 37 "src/io/Writer.birch"
    base_type_() {
  //
}

#line 85 "src/io/Writer.birch"
void Writer_::visit(const numbirch::Future<Real>& value) {
  #line 86 "src/io/Writer.birch"
  return visit((*(value)));
}

#line 89 "src/io/Writer.birch"
void Writer_::visit(const numbirch::Future<Integer>& value) {
  #line 90 "src/io/Writer.birch"
  return visit((*(value)));
}

#line 93 "src/io/Writer.birch"
void Writer_::visit(const numbirch::Future<Boolean>& value) {
  #line 94 "src/io/Writer.birch"
  return visit((*(value)));
}


/**
 * Create a writer for a file.
 *
 * @param path Path of the file.
 *
 * @return the writer.
 *
 * The file extension of `path` is used to determine the precise type of the
 * returned object. Supported file extension are `.json` and `.yml`.
 */
#line 108 "src/io/Writer.birch"
Writer make_writer(const String& path) {
  auto ext = extension(path);
  std::optional<Writer> result;
  #line 111 "src/io/Writer.birch"
  if (ext == String(".json")) {
    JSONWriter writer;
    #line 113 "src/io/Writer.birch"
    writer->open(path);
    #line 114 "src/io/Writer.birch"
    result = writer;
  } else {
    #line 115 "src/io/Writer.birch"
    if (ext == String(".yml")) {
      YAMLWriter writer;
      #line 117 "src/io/Writer.birch"
      writer->open(path);
      #line 118 "src/io/Writer.birch"
      result = writer;
    }
  }
  #line 120 "src/io/Writer.birch"
  if (!((bool(result)))) {
    #line 121 "src/io/Writer.birch"
    error(String("unrecognized file extension '") + ext + String("' in path '") + path + String("'; supported extensions are '.json' and '.yml'."));
  }
  #line 124 "src/io/Writer.birch"
  return (*(result));
}


/**
 * Write the whole contents of a buffer into a file.
 *
 * @param path Path of the file.
 * @param buffer The contents.
 */
#line 133 "src/io/Writer.birch"
void dump(const String& path, const Buffer& buffer) {
  auto writer = make_writer(path);
  #line 135 "src/io/Writer.birch"
  writer->dump(buffer);
  #line 136 "src/io/Writer.birch"
  writer->close();
}

}
namespace birch {
#line 1 "src/io/YAMLReader.birch"
YAMLReader_::YAMLReader_() :
    #line 1 "src/io/YAMLReader.birch"
    base_type_(),
    #line 24 "src/io/YAMLReader.birch"
    file(),
    #line 29 "src/io/YAMLReader.birch"
    sequential(false) {
  //
}

#line 36 "src/io/YAMLReader.birch"
void YAMLReader_::open(const String& path) {
  #line 37 "src/io/YAMLReader.birch"
  file = fopen(path, READ);
  #line 38 "src/io/YAMLReader.birch"

    yaml_parser_initialize(&parser);
    yaml_parser_set_input_file(&parser, file);
    if (!yaml_parser_parse(&parser, &event)) {
      error("parse error");
    }
    }

#line 47 "src/io/YAMLReader.birch"
void YAMLReader_::close() {
  #line 48 "src/io/YAMLReader.birch"

    yaml_event_delete(&event);
    yaml_parser_delete(&parser);
    fclose(file);
    }

#line 55 "src/io/YAMLReader.birch"
Buffer YAMLReader_::slurp() {
  #line 56 "src/io/YAMLReader.birch"
  assert(!(sequential));
  Buffer buffer;
  #line 58 "src/io/YAMLReader.birch"

    while (event.type != YAML_STREAM_END_EVENT) {
      if (event.type == YAML_SEQUENCE_START_EVENT) {
        parseSequence(buffer);
      } else if (event.type == YAML_MAPPING_START_EVENT) {
        parseMapping(buffer);
      } else if (event.type == YAML_SCALAR_EVENT) {
        parseValue(buffer);
      }
      nextEvent();
    }
      #line 70 "src/io/YAMLReader.birch"
  return buffer;
}

#line 73 "src/io/YAMLReader.birch"
Boolean YAMLReader_::hasNext() {
  #line 74 "src/io/YAMLReader.birch"

    while (event.type != YAML_MAPPING_START_EVENT &&
        event.type != YAML_SEQUENCE_START_EVENT &&
        event.type != YAML_SCALAR_EVENT &&
        event.type != YAML_STREAM_END_EVENT) {
      nextEvent();
    }
    if (!sequential && event.type == YAML_SEQUENCE_START_EVENT) {
      /* root is a sequence to iterate through, go one level deeper to find
       * its first element, if any */
      nextEvent();
      while (event.type != YAML_MAPPING_START_EVENT &&
          event.type != YAML_SEQUENCE_START_EVENT &&
          event.type != YAML_SCALAR_EVENT &&
          event.type != YAML_STREAM_END_EVENT) {
        nextEvent();
      }
    }
    sequential = true;
    return event.type != YAML_STREAM_END_EVENT;
      #line 95 "src/io/YAMLReader.birch"
  return false;
}

#line 98 "src/io/YAMLReader.birch"
Buffer YAMLReader_::next() {
  #line 99 "src/io/YAMLReader.birch"
  if (!(sequential)) {
    #line 100 "src/io/YAMLReader.birch"
    hasNext();
  }
  Buffer buffer;
  #line 103 "src/io/YAMLReader.birch"

    if (event.type == YAML_SCALAR_EVENT) {
      parseValue(buffer);
    } else if (event.type == YAML_SEQUENCE_START_EVENT) {
      parseSequence(buffer);
    } else if (event.type == YAML_MAPPING_START_EVENT) {
      parseMapping(buffer);
    } else {
      /* shouldn't get here if hasNext() was called before next() */
      assert(false);
    }
    nextEvent();
      #line 116 "src/io/YAMLReader.birch"
  return buffer;
}

#line 122 "src/io/YAMLReader.birch"
void YAMLReader_::parseMapping(const Buffer& buffer) {
  #line 123 "src/io/YAMLReader.birch"
  buffer->setEmptyObject();
  #line 124 "src/io/YAMLReader.birch"

    nextEvent();
    while (event.type != YAML_MAPPING_END_EVENT) {
      if (event.type == YAML_SCALAR_EVENT) {
        /* key */
        char* data = (char*)event.data.scalar.value;
        size_t length = event.data.scalar.length;
        std::string key(data, length);
      
        /* value */
        nextEvent();
        auto value = make_buffer();
        if (event.type == YAML_SCALAR_EVENT) {
          parseValue(value);
        } else if (event.type == YAML_SEQUENCE_START_EVENT) {
          parseSequence(value);
        } else if (event.type == YAML_MAPPING_START_EVENT) {
          parseMapping(value);
        }

        /* set key/value entry */
        buffer->set(key, value);
      }
      nextEvent();
    }
    }

#line 155 "src/io/YAMLReader.birch"
void YAMLReader_::parseSequence(const Buffer& buffer) {
  #line 156 "src/io/YAMLReader.birch"

    nextEvent();
    while (event.type != YAML_SEQUENCE_END_EVENT) {
      if (event.type == YAML_SCALAR_EVENT) {
        parseElement(buffer);
      } else if (event.type == YAML_SEQUENCE_START_EVENT) {
        auto element = make_buffer();
        parseSequence(element);

        /* attempt to merge sequences into numerical matrices */
        if (element->vectorReal.has_value()) {
          buffer->push(element->vectorReal.value());
        } else if (element->vectorInteger.has_value()) {
          buffer->push(element->vectorInteger.value());
        } else if (element->vectorBoolean.has_value()) {
          buffer->push(element->vectorBoolean.value());
        } else {
          buffer->push(element);
        }
      } else if (event.type == YAML_MAPPING_START_EVENT) {
        auto element = make_buffer();
        parseMapping(element);
        buffer->push(element);
      }
      nextEvent();
    }
    }

#line 188 "src/io/YAMLReader.birch"
void YAMLReader_::parseValue(const Buffer& buffer) {
  #line 189 "src/io/YAMLReader.birch"

    auto data = (char*)event.data.scalar.value;
    auto length = event.data.scalar.length;
    auto endptr = data;
    auto intValue = Integer(std::strtol(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->set(intValue);
    } else {
      auto realValue = Real(std::strtod(data, &endptr));
      if (endptr == data + length) {
        buffer->set(Real(realValue));
      } else if (std::strcmp(data, "true") == 0) {
        buffer->set(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->set(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->setNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->set(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->set(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->set(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->set(std::string(data, length));
      }
    }
    }

#line 222 "src/io/YAMLReader.birch"
void YAMLReader_::parseElement(const Buffer& buffer) {
  #line 223 "src/io/YAMLReader.birch"

    auto data = (char*)event.data.scalar.value;
    auto length = event.data.scalar.length;
    auto endptr = data;
    auto intValue = Integer(std::strtol(data, &endptr, 10));
    if (endptr == data + length) {
      buffer->push(intValue);
    } else {
      auto realValue = Real(std::strtod(data, &endptr));
      if (endptr == data + length) {
        buffer->push(realValue);
      } else if (std::strcmp(data, "true") == 0) {
        buffer->push(true);
      } else if (std::strcmp(data, "false") == 0) {
        buffer->push(false);
      } else if (std::strcmp(data, "null") == 0) {
        buffer->pushNil();
      } else if (std::strcmp(data, "Infinity") == 0) {
        buffer->push(std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "-Infinity") == 0) {
        buffer->push(-std::numeric_limits<Real>::infinity());
      } else if (std::strcmp(data, "NaN") == 0) {
        buffer->push(std::numeric_limits<Real>::quiet_NaN());
      } else {
        buffer->push(std::string(data, length));
      }
    }
    }

#line 256 "src/io/YAMLReader.birch"
void YAMLReader_::nextEvent() {
  #line 257 "src/io/YAMLReader.birch"

    yaml_event_delete(&event);
    if (!yaml_parser_parse(&parser, &event)) {
      error("parse error");
    }
    }

#line 1 "src/io/YAMLReader.birch"
Object_* make_YAMLReader_() {
  #line 1 "src/io/YAMLReader.birch"
  return new YAMLReader_();
  #line 1 "src/io/YAMLReader.birch"
}
static int register_factory_YAMLReader_ = ::register_factory("YAMLReader", make_YAMLReader_);

}
namespace birch {
#line 1 "src/io/YAMLWriter.birch"
YAMLWriter_::YAMLWriter_() :
    #line 1 "src/io/YAMLWriter.birch"
    base_type_(),
    #line 17 "src/io/YAMLWriter.birch"
    file(),
    #line 22 "src/io/YAMLWriter.birch"
    sequential(false) {
  //
}

#line 29 "src/io/YAMLWriter.birch"
void YAMLWriter_::open(const String& path) {
  #line 30 "src/io/YAMLWriter.birch"
  file = fopen(path, WRITE);
  #line 31 "src/io/YAMLWriter.birch"

    yaml_emitter_initialize(&this->emitter);
    yaml_emitter_set_unicode(&this->emitter, 1);
    yaml_emitter_set_output_file(&this->emitter, this->file);
    yaml_stream_start_event_initialize(&this->event, YAML_UTF8_ENCODING);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_document_start_event_initialize(&this->event, NULL, NULL, NULL, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 42 "src/io/YAMLWriter.birch"
void YAMLWriter_::dump(const Buffer& buffer) {
  #line 43 "src/io/YAMLWriter.birch"
  buffer->accept(membirch::Shared<this_type_>(this));
}

#line 46 "src/io/YAMLWriter.birch"
void YAMLWriter_::push(const Buffer& buffer) {
  #line 47 "src/io/YAMLWriter.birch"
  if (!(sequential)) {
    #line 48 "src/io/YAMLWriter.birch"
    startSequence();
    #line 49 "src/io/YAMLWriter.birch"
    sequential = true;
  }
  #line 51 "src/io/YAMLWriter.birch"
  buffer->accept(membirch::Shared<this_type_>(this));
}

#line 54 "src/io/YAMLWriter.birch"
void YAMLWriter_::flush() {
  #line 55 "src/io/YAMLWriter.birch"

    yaml_emitter_flush(&this->emitter);
    fflush(file);
    }

#line 61 "src/io/YAMLWriter.birch"
void YAMLWriter_::close() {
  #line 62 "src/io/YAMLWriter.birch"
  if (sequential) {
    #line 63 "src/io/YAMLWriter.birch"
    endSequence();
  }
  #line 65 "src/io/YAMLWriter.birch"

    yaml_document_end_event_initialize(&this->event, 1);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_stream_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    yaml_emitter_delete(&this->emitter);
    fclose(file);
    }

#line 75 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const Array<String>& keys, const Array<Buffer>& values) {
  #line 76 "src/io/YAMLWriter.birch"
  assert(keys->size() == values->size());
  #line 77 "src/io/YAMLWriter.birch"
  startMapping();
  #line 78 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(keys->size()); ++i) {
    #line 79 "src/io/YAMLWriter.birch"
    visit(keys(i));
    #line 80 "src/io/YAMLWriter.birch"
    values(i)->accept(membirch::Shared<this_type_>(this));
  }
  #line 82 "src/io/YAMLWriter.birch"
  endMapping();
}

#line 85 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const Array<Buffer>& values) {
  #line 86 "src/io/YAMLWriter.birch"
  startSequence();
  #line 87 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(values->size()); ++i) {
    #line 88 "src/io/YAMLWriter.birch"
    values(i)->accept(membirch::Shared<this_type_>(this));
  }
  #line 90 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 93 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const Boolean& value) {
  auto str = to_string(value);
  #line 95 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 103 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const Integer& value) {
  auto str = to_string(value);
  #line 105 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 113 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const Real& value) {
  String str;
  #line 118 "src/io/YAMLWriter.birch"
  if (value == std::numeric_limits<Real>::infinity()) {
    #line 119 "src/io/YAMLWriter.birch"
    str = String("Infinity");
  } else {
    #line 120 "src/io/YAMLWriter.birch"
    if (value == -(std::numeric_limits<Real>::infinity())) {
      #line 121 "src/io/YAMLWriter.birch"
      str = String("-Infinity");
    } else {
      #line 122 "src/io/YAMLWriter.birch"
      if (isnan(value)) {
        #line 123 "src/io/YAMLWriter.birch"
        str = String("NaN");
      } else {
        #line 125 "src/io/YAMLWriter.birch"
        str = to_string(value);
      }
    }
  }
  #line 127 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)str.c_str(), str.length(), 1, 1,
        YAML_PLAIN_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 135 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const String& value) {
  #line 136 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)value.c_str(), value.length(), 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 144 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Boolean,1>& value) {
  #line 145 "src/io/YAMLWriter.birch"
  startSequence();
  #line 146 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(length(value)); ++i) {
    #line 147 "src/io/YAMLWriter.birch"
    visit(value(i));
  }
  #line 149 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 152 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Integer,1>& value) {
  #line 153 "src/io/YAMLWriter.birch"
  startSequence();
  #line 154 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(length(value)); ++i) {
    #line 155 "src/io/YAMLWriter.birch"
    visit(value(i));
  }
  #line 157 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 160 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Real,1>& value) {
  #line 161 "src/io/YAMLWriter.birch"
  startSequence();
  #line 162 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(length(value)); ++i) {
    #line 163 "src/io/YAMLWriter.birch"
    visit(value(i));
  }
  #line 165 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 168 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Boolean,2>& value) {
  #line 169 "src/io/YAMLWriter.birch"
  startSequence();
  #line 170 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(rows(value)); ++i) {
    #line 171 "src/io/YAMLWriter.birch"
    visit(row(value, i));
  }
  #line 173 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 176 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Integer,2>& value) {
  #line 177 "src/io/YAMLWriter.birch"
  startSequence();
  #line 178 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(rows(value)); ++i) {
    #line 179 "src/io/YAMLWriter.birch"
    visit(row(value, i));
  }
  #line 181 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 184 "src/io/YAMLWriter.birch"
void YAMLWriter_::visit(const numbirch::Array<Real,2>& value) {
  #line 185 "src/io/YAMLWriter.birch"
  startSequence();
  #line 186 "src/io/YAMLWriter.birch"
  for (int i = int(1); i <= int(rows(value)); ++i) {
    #line 187 "src/io/YAMLWriter.birch"
    visit(row(value, i));
  }
  #line 189 "src/io/YAMLWriter.birch"
  endSequence();
}

#line 192 "src/io/YAMLWriter.birch"
void YAMLWriter_::visitNil() {
  #line 193 "src/io/YAMLWriter.birch"

    yaml_scalar_event_initialize(&this->event, NULL, NULL,
        (yaml_char_t*)"null", 4, 1, 1,
        YAML_ANY_SCALAR_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 201 "src/io/YAMLWriter.birch"
void YAMLWriter_::startMapping() {
  #line 202 "src/io/YAMLWriter.birch"

    yaml_mapping_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_MAPPING_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 209 "src/io/YAMLWriter.birch"
void YAMLWriter_::endMapping() {
  #line 210 "src/io/YAMLWriter.birch"

    yaml_mapping_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 216 "src/io/YAMLWriter.birch"
void YAMLWriter_::startSequence() {
  #line 217 "src/io/YAMLWriter.birch"

    yaml_sequence_start_event_initialize(&this->event, NULL, NULL, 1,
        YAML_ANY_SEQUENCE_STYLE);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 224 "src/io/YAMLWriter.birch"
void YAMLWriter_::endSequence() {
  #line 225 "src/io/YAMLWriter.birch"

    yaml_sequence_end_event_initialize(&this->event);
    yaml_emitter_emit(&this->emitter, &this->event);
    }

#line 1 "src/io/YAMLWriter.birch"
Object_* make_YAMLWriter_() {
  #line 1 "src/io/YAMLWriter.birch"
  return new YAMLWriter_();
  #line 1 "src/io/YAMLWriter.birch"
}
static int register_factory_YAMLWriter_ = ::register_factory("YAMLWriter", make_YAMLWriter_);

}
