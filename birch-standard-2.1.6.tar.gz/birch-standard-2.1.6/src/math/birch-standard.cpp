namespace birch {

/**
 * $\pi$
 */
#line 5 "src/math/constant.birch"
Real \u03c0 = Real(3.1415926535897932384626433832795);
}
namespace birch {
}
namespace birch {

/**
 * Seed the pseudorandom number generator.
 *
 * @param seed Seed value.
 */
#line 6 "src/math/rng.birch"
void seed(const Integer& s) {
  #line 7 "src/math/rng.birch"

  numbirch::seed(s);
  }


/**
 * Seed the pseudorandom number generator with entropy.
 */
#line 15 "src/math/rng.birch"
void seed() {
  #line 16 "src/math/rng.birch"

  numbirch::seed();
  }

}
