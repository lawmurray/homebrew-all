See [section-6-contributing.md](./docs/section-6-contributing.md)
